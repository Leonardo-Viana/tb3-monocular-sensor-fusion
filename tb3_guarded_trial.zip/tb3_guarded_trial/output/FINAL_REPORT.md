# Autonomous textured-scene mapping: execution report

Generated 2026-10-02T18:44:46.735801+00:00.

## Actual terminal state

The guarded-tracker controller stopped with reason **reachable_view_coverage_complete**. It reached 99 goals and travelled approximately 37.702 m according to fused map-frame pose increments. This is not ground-truth distance. It recorded 8 failed goals and 0 limited recovery attempts. The supervisor's separate manifest records any infrastructure error.



## Last completed reconstruction

The last completed fit contains 4029 accepted sparse RGB landmark IDs from 1948 keyframes. Reserved pixels: {'n': 8920, 'median': 0.23998359568419114, 'p90': 0.7478224091000927, 'max': 7.68852030060223}. Aggregate pixel gate: True. Consult the numerical evidence for full tails, unscored observations and nonconverged blocks. Counts may include multiple IDs for one physical feature. Reconstruction may lag the newest acquired frame if a final job failed or timed out; the keyframe file and fit summary preserve both sizes.

Planner metrics: {"frontier_groups": 0, "frontier_cells": 0, "view_goals_total": 160, "view_goals_covered": 156, "view_goals_blocked": 3, "view_coverage": 0.975, "free_area_m2": 19.62559912266732, "reachable_area_m2": 8.247999631285671, "reason": "home_reached"}. Coverage refers to a finite reachable camera-view lattice, not dense surface completeness. Full 3D completion and absolute metric accuracy are **not established**.

The estimator consumed RGB image rays, wheel velocity, raw gyro/accelerometer, and 2D LiDAR pose support. No RGB-D, compass, IMU orientation field or simulator/world geometry was an estimator input. Historical datasets were preserved. This trial starts from an empty estimator state and uses the guarded tracker with unchanged reconstruction thresholds. The historical baseline is stored separately.

## Recordings

1 MCAP recording segments were traversed. All per-topic count comparisons passed: True. First and last RGB frames were decoded for every segment. Raw data remain at the paths and hashes in FINAL_REPORT.json; successful traversal is not proof of zero acquisition loss.

One RViz is used for the live/saved mission display. The simulator is requested to pause on supervisor termination. The command audit retains final observed velocity commands. See the audit and supervisor manifest rather than inferring robot state from this report alone.

This is one prospective development repeat with a guarded tracker, not a randomized or statistically replicated causal comparison. Closed-loop paths and runtime load can differ from the baseline. No publication or public upload was performed.
