"""Read-only RGB correspondence audit; no ROS, simulator geometry or motion."""
import argparse, json, hashlib, time
from pathlib import Path
from collections import defaultdict
import numpy as np
import cv2
from scipy.spatial.transform import Rotation

def stats(x):
    x=np.asarray(x,float)
    return dict(n=len(x),median=float(np.median(x)),p90=float(np.percentile(x,90)),max=float(x.max())) if len(x) else {'n':0}

def main(root,out):
    cv2.setNumThreads(1);cv2.setRNGSeed(1729);out.mkdir(exist_ok=True)
    started=time.monotonic()
    data=json.loads((root/'keyframes.json').read_text());tracks=json.loads((root/'tracks.json').read_text())
    landmarks=json.loads((root/'stable/stable_landmarks.json').read_text());points={p['track_id']:p for p in landmarks}
    T=np.array([f['T'] for f in data['frames']]);stamps=np.array([f['stamp'] for f in data['frames']]);K=np.array(data['K'])
    # Use the same final planar graph warp as the estimator solely to select candidate views.
    import sys
    sys.path.insert(0,str(root.parent))
    from geometry import graph_warp
    nodes={int(k):np.array(v) for k,v in data['graph'].items()}
    corrected=np.array([graph_warp(t,{int(k):np.array(v) for k,v in f['anchors'].items()},nodes) for t,f in zip(T,data['frames'])])
    perframe=defaultdict(list);observations={}
    for tid,p in points.items():
        obs={int(f):np.array(uv,float) for f,uv in tracks[str(tid)]['obs']}
        observations[tid]=obs
        # Only observations used in training/validation, never the inspected held-out pixels.
        for f in p['train_frames']+p['validation_frames']:
            if f in obs:perframe[f].append((tid,obs[f]))
    eligible=sorted(f for f,v in perframe.items() if len(v)>=12)
    candidates=[]
    for ix,b in enumerate(eligible):
        for a in eligible[:ix]:
            gap=stamps[b]-stamps[a]
            if gap<40:continue
            dist=float(np.linalg.norm(corrected[a,:3,3]-corrected[b,:3,3]))
            angle=float(np.degrees(np.arccos(np.clip(corrected[a,:3,2]@corrected[b,:3,2],-1,1))))
            if dist<=.60 and angle<=30:candidates.append((dist/.60+angle/30,a,b,dist,angle,gap))
    selected=[]
    for c in sorted(candidates):
        _,a,b,*_=c
        if any(abs(stamps[a]-stamps[aa])<3 and abs(stamps[b]-stamps[bb])<3 for _,aa,bb,*_ in selected):continue
        selected.append(c)
        if len(selected)>=80:break
    sift=cv2.SIFT_create();bf=cv2.BFMatcher(cv2.NORM_L2);cache={}
    def descriptors(fid):
        if fid in cache:return cache[fid]
        im=cv2.imread(str(root/'frames'/f'{fid:05d}.jpg'),cv2.IMREAD_GRAYSCALE)
        items=perframe[fid]
        keys=[cv2.KeyPoint(float(uv[0]),float(uv[1]),24.,0.,1.,0,int(tid)) for tid,uv in items]
        keys,d=sift.compute(im,keys)
        ids=np.array([k.class_id for k in keys]);xy=np.array([k.pt for k in keys])
        cache[fid]=(ids,xy,d)
        return cache[fid]
    def ratio_matches(a,b):
        if a is None or b is None or min(len(a),len(b))<2:return {}
        return {pair[0].queryIdx:pair[0].trainIdx for pair in bf.knnMatch(a,b,k=2) if len(pair)==2 and pair[0].distance<.70*pair[1].distance}
    pairs=[];all_matches=[]
    for ix,(_,a,b,dist,angle,gap) in enumerate(selected):
        ia,ua,da=descriptors(a);ib,ub,db=descriptors(b)
        ab=ratio_matches(da,db);ba=ratio_matches(db,da)
        mm=[]
        for i,j in ab.items():
            if ba.get(j)!=i:continue
            t1,t2=int(ia[i]),int(ib[j])
            if t1==t2:continue
            if max(observations[t1])>=min(observations[t2]) and max(observations[t2])>=min(observations[t1]):continue
            mm.append((i,j,t1,t2))
        mask=np.zeros(len(mm),bool);spread=False
        if len(mm)>=12:
            u1=np.array([ua[i] for i,j,t1,t2 in mm]);u2=np.array([ub[j] for i,j,t1,t2 in mm])
            spread=bool(np.all(np.ptp(u1,axis=0)>40) and np.all(np.ptp(u2,axis=0)>40))
            if spread:
                F,m=cv2.findFundamentalMat(u1,u2,cv2.FM_RANSAC,2.,.999,5000)
                if F is not None and F.shape==(3,3) and m is not None:mask=m.ravel().astype(bool)
        details=[]
        for q,(i,j,t1,t2) in enumerate(mm):
            x1=np.array(points[t1]['xyz']);x2=np.array(points[t2]['xyz']);delta=x2-x1
            row={'frame_a':a,'frame_b':b,'track_a':t1,'track_b':t2,'uv_a':ua[i].tolist(),'uv_b':ub[j].tolist(),'delta_m':delta.tolist(),'distance_m':float(np.linalg.norm(delta)),'z_difference_m':float(abs(delta[2])),'epipolar_supported':bool(mask[q]),'block_a':points[t1]['block'],'block_b':points[t2]['block']}
            details.append(row);all_matches.append(row)
        pairs.append({'frame_a':a,'frame_b':b,'gap_sim_s':float(gap),'camera_distance_m':dist,'direction_degrees':angle,'available_a':len(ia),'available_b':len(ib),'mutual_ratio_matches':len(mm),'epipolar_inliers':int(mask.sum()),'image_spread_pass':spread,'residuals_m':stats([r['distance_m'] for r in details])})
        if ix%10==0:print(json.dumps({'pairs_done':ix+1,'matches':len(all_matches)}),flush=True)
    # One vote per unordered landmark pair; repeated image support is reported separately.
    grouped=defaultdict(list)
    for r in all_matches:grouped[tuple(sorted((r['track_a'],r['track_b'])))].append(r)
    unique=[]
    for key,rows in grouped.items():
        r=dict(rows[0]);r['image_pair_support']=len(rows);r['epipolar_supported']=any(x['epipolar_supported'] for x in rows)
        r['repeat_support']=any(abs(stamps[x['frame_a']]-stamps[y['frame_a']])>=.32 and abs(stamps[x['frame_b']]-stamps[y['frame_b']])>=.32 for x in rows for y in rows)
        unique.append(r)
    def subset(rows):
        return {'landmark_pairs':len(rows),'tested_unique_ids':len({r[k] for r in rows for k in ['track_a','track_b']}),'euclidean_m':stats([r['distance_m'] for r in rows]),'vertical_m':stats([r['z_difference_m'] for r in rows]),'block_pairs':sorted(set(tuple(sorted((r['block_a'],r['block_b']))) for r in rows))}
    summary={'candidate_image_pairs':len(candidates),'selected_image_pairs':len(selected),'raw_image_matches':len(all_matches),'raw_unique':subset(unique),'epipolar_subset':subset([r for r in unique if r['epipolar_supported']]),'repeat_image_subset':subset([r for r in unique if r['repeat_support']]),'both_checks_subset':subset([r for r in unique if r['repeat_support'] and r['epipolar_supported']]),'elapsed_s':time.monotonic()-started,'source_hashes':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['keyframes.json','tracks.json','stable/stable_landmarks.json']},'no_3d_registration_or_distance_gating':True,'evaluation':'Exploratory consistency of RGB candidate associations, not ground truth or an independent journey.'}
    (out/'revisit_summary.json').write_text(json.dumps(summary,indent=2));(out/'revisit_pairs.json').write_text(json.dumps(pairs,indent=2));(out/'revisit_matches.json').write_text(json.dumps(unique,indent=2));(out/'revisit_all_image_matches.json').write_text(json.dumps(all_matches,indent=2))
    print(json.dumps(summary),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);a=p.parse_args();main(a.root,a.out)
