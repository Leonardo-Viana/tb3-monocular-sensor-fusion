"""Post-run descriptive comparison. Never publishes ROS or controls Gazebo."""
import sys,json,time,subprocess,hashlib,datetime,os
from pathlib import Path
import psutil
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output'
BASE=Path('/home/lpviana/tb3_autonomous_texture_20261001')
owner=int(sys.argv[1]);finalizer=int(sys.argv[2])
def alive(pid):
    try:return psutil.Process(pid).status()!='zombie'
    except psutil.NoSuchProcess:return False
def read(path,default=None):
    return json.loads(path.read_text()) if path.exists() else default
while alive(owner) or alive(finalizer):time.sleep(3)
audit=ROOT/'revisit_audit';audit.mkdir(exist_ok=True)
if (OUT/'stable/stable_landmarks.json').exists():
    r=subprocess.run(['python3',str(audit/'audit_revisits.py'),str(OUT),str(audit)],env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'),capture_output=True,text=True,timeout=180)
    (audit/'revisit.log').write_text(r.stdout+r.stderr)
def collect(root):
    out=root/'output';s=read(out/'autonomy_status.json',{});v=read(out/'stable/validation.json',{});vision=read(out/'vision_status.json',{})
    prior=[read(p,{}) for p in sorted((out/'attempts').glob('*/autonomy_status.json'))]
    rr=read(root/'revisit_audit/revisit_summary.json') or read(root/'revisit_audit_20261002/revisit_summary.json',{})
    memory=[];last=None
    for f in [*sorted((out/'attempts').glob('*/mission_audit.jsonl')),out/'mission_audit.jsonl']:
        if not f.exists():continue
        for line in f.open():
            try:a=json.loads(line)
            except ValueError:continue
            if 'available_mib' in a:memory.append(a['available_mib'])
            if 'last_command' in a:last=a['last_command']
    return {'status':s,'stable':v,'vision':vision,'prior_segments':prior,'all_segments_wall_s':sum(x.get('elapsed_wall_s',0) for x in prior)+s.get('elapsed_wall_s',0),'all_segments_estimated_travel_m':sum(x.get('travelled_m',0) for x in prior)+s.get('travelled_m',0),'all_segments_goals':sum(x.get('goals_reached',0) for x in prior)+s.get('goals_reached',0),'minimum_available_mib':min(memory) if memory else None,'last_audited_command':last,'revisit':rr,'bag_report':read(out/'FINAL_REPORT.json',{}).get('bags',[])}
baseline=collect(BASE);trial=collect(ROOT)
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':baseline,'guarded_trial':trial,'descriptive_only':True,'dense_or_absolute_accuracy_established':False,'tracker_parameters_changed_during_trial':False,'limitations':['One adaptive run per configuration','Different controller budgets and path histories','Original baseline includes a preserved synchronous-timeout segment','Reserved pixels are internal within-track tests','Revisit associations are candidate matches, not surveyed ground truth']}
(ROOT/'COMPARISON.json').write_text(json.dumps(report,indent=2))
def metric(d,name):
    s=d['status'];v=d['stable']
    values={'Terminal reason':s.get('reason'),'Accepted sparse IDs':v.get('accepted_landmarks',0),'Keyframes in final fit':v.get('frames',0),'View coverage':s.get('map_metrics',{}).get('view_coverage'),'Total recorded controller wall seconds':d['all_segments_wall_s'],'Estimated travel across segments (m)':d['all_segments_estimated_travel_m'],'Goals reached across segments':d['all_segments_goals'],'Median reserved-pixel residual (px)':v.get('test_pixels',{}).get('median'),'P90 reserved-pixel residual (px)':v.get('test_pixels',{}).get('p90'),'Maximum reserved-pixel residual (px)':v.get('test_pixels',{}).get('max'),'Reserved observations >8 px':v.get('test_pixels_over_8px'),'Unscored accepted IDs':v.get('test_unscored_landmarks'),'Minimum available memory (MiB)':d['minimum_available_mib'],'Final audited velocity':d['last_audited_command']}
    return values.get(name)
names=['Terminal reason','Accepted sparse IDs','Keyframes in final fit','View coverage','Total recorded controller wall seconds','Estimated travel across segments (m)','Goals reached across segments','Median reserved-pixel residual (px)','P90 reserved-pixel residual (px)','Maximum reserved-pixel residual (px)','Reserved observations >8 px','Unscored accepted IDs','Minimum available memory (MiB)','Final audited velocity']
lines=['# Guarded tracker: prospective development repeat','',f"Generated {report['created_utc']}.",'','The following comparison is descriptive. The previous run is preserved, including its first timeout segment. Both configurations use the same reconstruction equations and gates, but adaptive routes, timing and navigation budgets can differ.','','| Measure | Original mission | Guarded repeat |','| --- | --- | --- |']
for name in names:lines.append(f'| {name} | {metric(baseline,name)} | {metric(trial,name)} |')
lines+=['','## Tracking and revisit evidence','',f"Final guarded-node counts: `{json.dumps(trial['vision'].get('counts',{}))}`.",'',f"Frozen revisit audit: `{json.dumps(trial['revisit'])}`.",'','No 3D-distance gate or point-cloud alignment selected revisit matches. Sample counts and residual tails must be considered alongside medians; small or empty subsets are inconclusive. A successful finite view-coverage criterion does not establish dense surfaces or absolute metric accuracy.','','## Preservation and interpretation','','The baseline was not modified. The new estimator started with empty map, track, landmark and cache state following a simulator reset. Only RGB rays supply 3D geometry. Wheel velocities, raw gyro/accelerometer and planar LiDAR retain the documented cascaded roles. No depth, compass, Imu.orientation or simulator geometry/pose was an estimator input.','','All outliers are retained in the reported reserved-pixel statistics. This one run cannot isolate the causal effect of the guard. Raw MCAP/JPEG/track inputs remain on the Dell; paths and hashes are in output/FINAL_REPORT.json. The final simulator pause and RViz count need a separate live readback.']
(ROOT/'COMPARISON.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'finished':True,'reason':trial['status'].get('reason'),'accepted':trial['stable'].get('accepted_landmarks',0),'comparison':str(ROOT/'COMPARISON.md')}),flush=True)
