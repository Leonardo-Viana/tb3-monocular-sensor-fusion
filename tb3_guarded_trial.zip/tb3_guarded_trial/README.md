# Guarded monocular mapping trial — completed

Completed on 2 October 2026. Start with **COMPARISON.md** for the English experimental report and **mission_map.png** for the saved result. The robot covered 156/160 planned reachable views (97.5%), returned home, and stopped. The sparse monocular map contains 4,029 accepted landmark IDs. Gazebo is paused and one RViz remains open. Global geometric accuracy and dense surface completeness are not established.

This prospective simulated TurtleBot3 Waffle mission is separate from the preserved baseline. See PROTOCOL.md for the fixed design and limitations. Runtime source verification is in source_verification.json; final stop verification is in output/final_verification.json.

The full experiment is on the Dell at /home/lpviana/tb3_guarded_trial_20261002. Raw recordings and JPEG/keyframe/track inputs remain there. This portable archive contains code, final PLY, numerical evidence, plots, and English reports; it is not a standalone copy of the entire raw dataset.

The launcher expects the matching paused textured Gazebo world and a fresh output directory. It refuses an existing run directory. Do not launch a second velocity controller. A STOP file in output requests termination. The supervisor stops control and recording, then pauses the simulator. No additional robot execution is needed to inspect these completed results.

The baseline experiment under /home/lpviana/tb3_autonomous_texture_20261001 remains intact. This comparison is descriptive because initial physical pose, adaptive trajectory, and budgets differ; it is not a controlled sensor or tracker ablation.
