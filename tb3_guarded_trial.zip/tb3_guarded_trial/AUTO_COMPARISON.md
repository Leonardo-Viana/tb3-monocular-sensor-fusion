# Guarded tracker: prospective development repeat

Generated 2026-10-02T18:44:53.363532+00:00.

The following comparison is descriptive. The previous run is preserved, including its first timeout segment. Both configurations use the same reconstruction equations and gates, but adaptive routes, timing and navigation budgets can differ.

| Measure | Original mission | Guarded repeat |
| --- | --- | --- |
| Terminal reason | reachable_view_coverage_complete | reachable_view_coverage_complete |
| Accepted sparse IDs | 4020 | 4029 |
| Keyframes in final fit | 1822 | 1948 |
| View coverage | 0.9736842105263158 | 0.975 |
| Total recorded controller wall seconds | 2109.0 | 1955.0 |
| Estimated travel across segments (m) | 31.921147590258983 | 37.70185371324093 |
| Goals reached across segments | 74 | 99 |
| Median reserved-pixel residual (px) | 0.28067136045692614 | 0.23998359568419114 |
| P90 reserved-pixel residual (px) | 0.854659685868618 | 0.7478224091000927 |
| Maximum reserved-pixel residual (px) | 264.9458448244183 | 7.68852030060223 |
| Reserved observations >8 px | 1 | 0 |
| Unscored accepted IDs | 2 | 0 |
| Minimum available memory (MiB) | 1357.13671875 | 741.5625 |
| Final audited velocity | [0.0, 0.0] | [0.0, 0.0] |

## Tracking and revisit evidence

Final guarded-node counts: `{"rgb_messages": 22946, "tf_wait": 304, "processed_frames": 1949, "features_started": 180071, "tracking_reset_image_gap": 140, "tracked_observations": 393262, "tracking_reset_camera_rotation": 10}`.

Frozen revisit audit: `{"candidate_image_pairs": 490, "selected_image_pairs": 14, "raw_image_matches": 105, "raw_unique": {"landmark_pairs": 77, "tested_unique_ids": 153, "euclidean_m": {"n": 77, "median": 0.060222717822429675, "p90": 0.1688432761924936, "max": 1.1316693139668363}, "vertical_m": {"n": 77, "median": 0.008275945510965166, "p90": 0.01765486055873922, "max": 0.03142198766371085}, "block_pairs": [[1, 22], [7, 9], [8, 9], [9, 28], [14, 15]]}, "epipolar_subset": {"landmark_pairs": 52, "tested_unique_ids": 104, "euclidean_m": {"n": 52, "median": 0.05814518821767102, "p90": 0.07845415613929277, "max": 0.11180202795296777}, "vertical_m": {"n": 52, "median": 0.00858730900572327, "p90": 0.013787723236867949, "max": 0.02372161438058784}, "block_pairs": [[8, 9]]}, "repeat_image_subset": {"landmark_pairs": 13, "tested_unique_ids": 26, "euclidean_m": {"n": 13, "median": 0.05993483757033081, "p90": 0.0872655486894491, "max": 0.1797000120851596}, "vertical_m": {"n": 13, "median": 0.007433277208333922, "p90": 0.013915849518369617, "max": 0.02372161438058784}, "block_pairs": [[1, 22], [8, 9]]}, "both_checks_subset": {"landmark_pairs": 10, "tested_unique_ids": 20, "euclidean_m": {"n": 10, "median": 0.05970493982531502, "p90": 0.08663274453993351, "max": 0.08744634987502498}, "vertical_m": {"n": 10, "median": 0.007521988113944472, "p90": 0.014083302032055907, "max": 0.02372161438058784}, "block_pairs": [[8, 9]]}, "elapsed_s": 3.5023653369862586, "source_hashes": {"keyframes.json": "d9f0de39321dba7370a72b382184f464ac5784306c5b423e7888113b7eafe897", "tracks.json": "d68c3748ae35ab033bad17362286e9da043c2956c76a8877aed8af61ef3e1fbd", "stable/stable_landmarks.json": "17d3898c85f5bddbb00f50d02016174907b67f32a55187ab3c4149da2e3369a8"}, "no_3d_registration_or_distance_gating": true, "evaluation": "Exploratory consistency of RGB candidate associations, not ground truth or an independent journey."}`.

No 3D-distance gate or point-cloud alignment selected revisit matches. Sample counts and residual tails must be considered alongside medians; small or empty subsets are inconclusive. A successful finite view-coverage criterion does not establish dense surfaces or absolute metric accuracy.

## Preservation and interpretation

The baseline was not modified. The new estimator started with empty map, track, landmark and cache state following a simulator reset. Only RGB rays supply 3D geometry. Wheel velocities, raw gyro/accelerometer and planar LiDAR retain the documented cascaded roles. No depth, compass, Imu.orientation or simulator geometry/pose was an estimator input.

All outliers are retained in the reported reserved-pixel statistics. This one run cannot isolate the causal effect of the guard. Raw MCAP/JPEG/track inputs remain on the Dell; paths and hashes are in output/FINAL_REPORT.json. The final simulator pause and RViz count need a separate live readback.
