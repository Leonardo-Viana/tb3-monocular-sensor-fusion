# Recorded RGB failure evidence

Four PNGs preserve the decoded, resized pixels from the original compressed sensor messages. They are not depth images or synthetic illustrations. Unzip beside the plot tool and supply this directory as its images argument. The fixtures are prior inspected development cases, not independent evaluation. Portable tests include seven analytic methods and one method with two recorded-failure subcases.
