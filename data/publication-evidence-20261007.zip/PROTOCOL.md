# Prospective replication and resource protocol — 7 October 2026

Status at registration: no new robot motion or ROS recording has started. Historical outputs remain immutable. This is an engineering replication phase, not a preregistered clinical study or a claim of publication readiness.

## Research scope

Evaluate sparse monocular reconstruction supported by planar LiDAR localization, wheel velocity and raw IMU measurements on a resource-constrained Dell Vostro 3710 (i5-12400, 8 GiB installed memory, Intel UHD 730). Simulation, recording, reconstruction and RViz run on this machine. Offloading computation or changing hardware constitutes a separate condition.

The 3D points must come from monocular RGB triangulation. Depth/RGB-D, compass, IMU orientation, simulator poses and scene geometry must not enter estimation or control. Scene assets are used only by the simulator. Clock is allowed for timing. Evaluation against independent references, if introduced later, must remain isolated from the estimator.

## Bounded first phase

Run up to three sequential textured-world trials, Gazebo seeds 23, 24 and 25, with identical starting pose, scene, estimator thresholds and 2400-second navigation budget. Each fresh run uses the archived guarded implementation with only transport isolation changed to ROS domain 75 and Gazebo partition `tb3_publication_20261007`. Record exact source hashes. Do not overwrite or selectively discard failed attempts. Different seeds and asynchronous scheduling mean trajectories need not be identical; results describe variation across this finite set, not generalization to arbitrary environments.

Use server-only Gazebo through the existing display with sensor rendering, one RViz instance and one controller. CPU linear-algebra thread limits remain one. Navigation, perception, recording and fitting execute concurrently as in the guarded baseline; trials do not run in parallel. Close only campaign-owned processes between trials. This changes the active desktop workload from historical captures and must be reported.

An independent wrapper enforces a 4500-second wall deadline per mission, starts only with at least 1700 MiB available RAM and 9 GiB free disk, and requests a stop below 450 MiB available RAM or 6 GiB free disk. Existing controller freshness, clearance, command lease and tighter refinement checks remain active. Any failed mission stops the sequence for diagnosis; do not automatically retry until success. A `STOP` file at the campaign root requests termination. The wrapper pauses simulator physics and cleans up its process descendants. These are operational bounds, not publication acceptance criteria.

## Measurements and provenance

- Preserve compressed RGB, intrinsics, planar scans, raw IMU, wheel odometry, joints, transforms, clock and velocity commands in MCAP on the Dell. Hash retained artifacts after recording ends; full raw bags are not committed directly to GitHub.
- Preserve keyframes, tracks, fixed split assignments, refinement reports, point clouds, navigation status, sensor resets, process exits and logs. Record all attempted runs, including empty maps and partial trajectories.
- Sample system CPU utilization, available memory, swap, free disk, per-process CPU time, RSS and PSS, and simulation-to-wall-clock progress approximately every five seconds. PSS sums cover discovered campaign descendants; RSS sums double-count shared pages. Sampling cannot establish exact transient peaks. Integrated-GPU memory is not separately measured and is not inferred from RSS.
- Mark startup, execution and cleanup intervals. RTF from clock progress includes pauses; separate actual exploration from fitting and idle periods during analysis. Record system and software versions and unrelated background workload as potential confounders. Do not claim the machine was otherwise idle.
- Distinguish hardware/resource limits, tool-access failures, GUI/authentication issues, software exceptions, numerical nonconvergence, poor visual observability and navigation/coverage failures. A timeout alone is not proof of a RAM or CPU limitation. Record evidence for attribution and report unknown causes as unknown.

## Analysis and readiness gates

Freeze reconstruction thresholds before inspecting new test metrics. Report each run, ranges and denominators; do not use three runs to imply strong statistical power. Report reserved-observation reprojection median, p90, maximum and tail counts, unscored points, accepted landmark IDs, spatial distribution, optimizer failures, tracking resets, view-lattice coverage, distance, wall duration, resource traces and return/stop state. Withheld observations are not an independent trajectory benchmark, and optimized shared poses limit their independence.

This phase alone is not sufficient for a claim of a complete or metrically accurate 3D map. Before a publication claim, require: reproducible instructions and preserved evidence; controlled sensor ablations with clearly stated confounders; a matched low-texture comparison; cross-view or independent geometric consistency evaluation; explicit failure cases and hardware limits; and a claim appropriately restricted to the evidence. Broader robustness requires additional scenes. Keep ground-truth evaluation separate from the estimation pipeline. Results may support a narrowly scoped engineering case study rather than a new SLAM algorithm or dense reconstruction claim.

After this bounded phase, review results before defining additional controlled trials. Do not keep generating favorable repeats until an arbitrary metric is met. Amend this protocol prospectively, preserve the original version and state why each change was made. User authorization covers continued simulated experiments; the runner is finite and does not itself decide scientific sufficiency or submit a paper.
