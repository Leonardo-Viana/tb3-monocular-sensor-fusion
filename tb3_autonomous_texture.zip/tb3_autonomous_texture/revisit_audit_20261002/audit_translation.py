"""Exploratory split-sample translation diagnostic, never edits the map."""
import json,hashlib,sys
from pathlib import Path
from collections import defaultdict
import numpy as np

def stats(x):
    x=np.asarray(x,float)
    return dict(n=len(x),median=float(np.median(x)),p90=float(np.percentile(x,90)),max=float(x.max())) if len(x) else {'n':0}

out=Path(sys.argv[1]);rows=json.loads((out/'revisit_matches.json').read_text())
groups=defaultdict(list)
for r in rows:
    if r['epipolar_supported']:groups[tuple(sorted([r['block_a'],r['block_b']]))].append(r)
results=[];before=[];after=[]
for key,values in sorted(groups.items()):
    values=sorted(values,key=lambda r:hashlib.sha256((':'.join(map(str,sorted((r['track_a'],r['track_b']))))+':translation-audit-20261002').encode()).hexdigest())
    if len(values)<12:results.append({'blocks':key,'n':len(values),'status':'insufficient_pairs'});continue
    train=values[::2];test=values[1::2]
    # Uniform orientation: add this translation to the larger block number.
    delta=np.array([r['delta_m'] if r['block_a']<r['block_b'] else -np.array(r['delta_m']) for r in train])
    correction=-np.median(delta,axis=0)
    held=np.array([r['delta_m'] if r['block_a']<r['block_b'] else -np.array(r['delta_m']) for r in test])
    d0=np.linalg.norm(held,axis=1);d1=np.linalg.norm(held+correction,axis=1)
    before.extend(d0);after.extend(d1)
    results.append({'blocks':key,'n':len(values),'train_n':len(train),'test_n':len(test),'translation_to_second_block_m':correction.tolist(),'heldout_before_m':stats(d0),'heldout_after_m':stats(d1),'train_pairs':[[r['track_a'],r['track_b']] for r in train],'test_pairs':[[r['track_a'],r['track_b']] for r in test]})
result={'method':'Median 3D translation per block pair; deterministic hash-sorted alternating split','split_decided_after_initial_aggregate_audit':True,'retrospective_development_only':True,'applied_to_baseline':False,'groups':results,'pooled_heldout_before_m':stats(before),'pooled_heldout_after_m':stats(after),'limitations':['Candidate RGB associations can be wrong','Both points share a fused-pose pipeline','Only a small subset of blocks is tested','An internal sample split is not an independent mission','No full-map deformation, loop closure, or accuracy claim']}
(out/'translation_diagnostic.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
