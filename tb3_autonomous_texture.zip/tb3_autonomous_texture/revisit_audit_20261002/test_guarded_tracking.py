"""Replay actual RGB frames through the candidate node without ROS publishers."""
import sys,json,tempfile,types
from pathlib import Path
from collections import Counter
import numpy as np
import cv2
from scipy.spatial.transform import Rotation
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import TransformStamped

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from monocular_guarded import Monocular
from geometry import OPTICAL_TO_BASE
from tracking_policy import transition_allowed

ROOT=Path(sys.argv[1]);data=json.loads((ROOT/'keyframes.json').read_text());tracks=json.loads((ROOT/'tracks.json').read_text());track=tracks['14326'];obs=dict(track['obs']);results=[]
cv2.setNumThreads(1)
class Sink:
    def publish(self,msg):pass

def replay(a,b):
    im=cv2.imread(str(ROOT/'frames'/f'{b:05d}.jpg'));previous=cv2.imread(str(ROOT/'frames'/f'{a:05d}.jpg'))
    m=CompressedImage();stamp=data['frames'][b]['stamp'];m.header.stamp.sec=int(stamp);m.header.stamp.nanosec=round((stamp-int(stamp))*1e9);m.data=cv2.imencode('.jpg',im)[1].tobytes()
    ta=np.array(data['frames'][a]['T']);tb=np.array(data['frames'][b]['T']);tf=TransformStamped()
    q=Rotation.from_matrix(tb[:3,:3]@OPTICAL_TO_BASE.T).as_quat()
    tf.transform.translation.x,tf.transform.translation.y,tf.transform.translation.z=map(float,tb[:3,3])
    tf.transform.rotation.x,tf.transform.rotation.y,tf.transform.rotation.z,tf.transform.rotation.w=map(float,q)
    n=object.__new__(Monocular);n.latest=m;n.K=np.array(data['K']);n.last_stamp=data['frames'][a]['stamp'];n.last_T=ta
    n.tracking_stamp=n.last_stamp;n.tracking_T=ta;n.old_gray=cv2.GaussianBlur(cv2.cvtColor(previous,cv2.COLOR_BGR2GRAY),(5,5),.9)
    n.active={14326:np.array(obs[a],np.float32)};n.tracks={14326:{'obs':[(a,np.array(obs[a],np.float32))],'rgb':np.array(track['rgb'],np.uint8)}};n.frames=[None]*b;n.next_id=200000;n.nodes={};n.count=Counter();n.landmarks=[];n.preview=Sink();n.tf=types.SimpleNamespace(lookup_transform=lambda *args:tf)
    with tempfile.TemporaryDirectory(prefix='tb3_guard_replay_') as d:
        n.out=Path(d);(n.out/'frames').mkdir();n.process()
    r={'from':a,'to':b,'continued_original_id':14326 in n.active,'old_track_last_frame':(n.tracks[14326]['obs'][-1][0] if 14326 in n.tracks else None),'new_keyframes':len(n.frames)-b,'counts':dict(n.count),'fresh_ids':sum(k>=200000 for k in n.active)}
    return r

bad=replay(170,171);assert bad['new_keyframes']==1 and not bad['continued_original_id'] and bad['old_track_last_frame'] is None and bad['counts'].get('tracking_reset_image_gap')==1 and bad['fresh_ids']>0
normal=replay(172,173);assert normal['new_keyframes']==1 and normal['continued_original_id'] and normal['old_track_last_frame']==173 and not any('reset' in k for k in normal['counts'])
I=np.eye(4);assert not transition_allowed(1,1,I,I)[0];assert not transition_allowed(2,1,I,I)[0];assert not transition_allowed(0,float('nan'),I,I)[0]
R=I.copy();R[:3,:3]=Rotation.from_euler('z',.25).as_matrix();assert not transition_allowed(0,.4,I,R)[0]
report={'passed':True,'failed_transition_replay':bad,'normal_transition_replay':normal,'invalid_time_and_large_rotation_checks_pass':True,'ros_nodes_started':False,'velocity_published':False,'limitations':'Saved JPEG replay and mocked TF; no fresh live trajectory and no new reconstruction accuracy claim.'}
(HERE/'guard_test_result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
