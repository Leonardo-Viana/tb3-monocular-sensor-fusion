"""Reproduce one frozen block and inspect the RGB transition behind its outlier."""
import json,sys,time,hashlib
from pathlib import Path
import numpy as np
import cv2
from scipy.spatial.transform import Rotation

ROOT=Path(sys.argv[1]);OUT=Path(sys.argv[2]);sys.path.insert(0,str(ROOT.parent))
started=time.monotonic();cv2.setNumThreads(1)
source=(ROOT.parent/'stable_cached.py').read_text()
needle='X,R,C,d=decode(fit.x);poses={f:raw[f].copy() for f in fids}'
replacement="X,R,C,d=decode(fit.x);globals()['AUDIT_OPTIMIZED']={'fids':fids,'R':R,'C':C,'d':d,'ci':ci};poses={f:raw[f].copy() for f in fids}"
assert source.count(needle)==1
scope={'__name__':'audit_fit','__file__':str(ROOT.parent/'stable_cached.py')};exec(compile(source.replace(needle,replacement),str(OUT/'instrumented_fit.py'),'exec'),scope)
data=json.loads((ROOT/'keyframes.json').read_text());tracks=json.loads((ROOT/'tracks.json').read_text());landmarks=json.loads((ROOT/'stable/stable_landmarks.json').read_text());point=next(p for p in landmarks if p['track_id']==14326)
K=np.array(data['K']);raw=np.array([scope['flat'](np.array(f['T'])) for f in data['frames']]);stamps=np.array([f['stamp'] for f in data['frames']])
items=[(tid,t) for tid,t in tracks.items() if len(t['obs'])>=6 and t['obs'][0][0]//64==2]
good,fitreport,errors=scope['fit_block'](2,items,raw,stamps,K)
rerun=next(p for p in good if p['track_id']==14326)
opt=scope['AUDIT_OPTIMIZED'];fm={f:i for i,f in enumerate(opt['fids'])}
obs=dict(tracks['14326']['obs']);rows=[]
for f,uv in tracks['14326']['obs']:
    if f not in fm:continue
    i=fm[f];q=K@(opt['R'][i].T@(np.array(rerun['xyz'])-opt['C'][i]));pred=q[:2]/q[2]
    rows.append({'frame':f,'stamp':float(stamps[f]),'observed':uv,'predicted':pred.tolist(),'error_px':float(np.linalg.norm(pred-uv)),'training_pose_support':int((opt['ci']==i).sum()),'pose_correction':opt['d'][i].tolist()})
a,b=170,171
images=[cv2.imread(str(ROOT/'frames'/f'{f:05d}.jpg')) for f in [a,b]]
grays=[cv2.GaussianBlur(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(5,5),.9) for im in images]
old=np.array(obs[a],np.float32).reshape(1,1,2)
new,st,err=cv2.calcOpticalFlowPyrLK(grays[0],grays[1],old,None,winSize=(25,25),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,40,.01))
back,sback,_=cv2.calcOpticalFlowPyrLK(grays[1],grays[0],new,None,winSize=(25,25),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,40,.01))
dt=float(stamps[b]-stamps[a]);rotation=float(Rotation.from_matrix(raw[a,:3,:3].T@raw[b,:3,:3]).magnitude());translation=float(np.linalg.norm(raw[b,:3,3]-raw[a,:3,3]))
all_dt=np.diff(stamps);all_rot=Rotation.from_matrix(raw[:-1,:3,:3].transpose(0,2,1)@raw[1:,:3,:3]).magnitude()
unsafe=np.where((all_dt>.65)|(all_dt<=0)|(all_rot>.18))[0]+1
unsafe_set=set(unsafe.tolist());crossing={}
for tid,t in tracks.items():
    fs=[int(f) for f,uv in t['obs']]
    crossed=[f for f in unsafe_set if min(fs)<f<=max(fs)]
    if crossed:crossing[int(tid)]=crossed
oldb=[p for p in landmarks if p['block']==2]
newmap={p['track_id']:p for p in good}
agreement=[float(np.linalg.norm(np.array(p['local_xyz'])-newmap[p['track_id']]['xyz'])) for p in oldb if p['track_id'] in newmap]
report={'track_id':14326,'original_test_errors_px':point['test_errors_px'],'rerun_test_errors_px':rerun['test_errors_px'],'fit':fitreport,'reproduced_same_ids':set(p['track_id'] for p in oldb)==set(newmap),'max_coordinate_difference_from_baseline_m':max(agreement,default=None),'transition':{'from':a,'to':b,'dt_sim_s':dt,'rotation_deg':float(np.degrees(rotation)),'translation_m':translation},'jpeg_replay_lk':{'next_xy':new.reshape(2).tolist(),'stored_next_xy':obs[b],'forward_backward_px':float(np.linalg.norm(back-old)),'photometric_error':float(err[0,0]),'statuses':[int(st[0,0]),int(sback[0,0])],'note':'Replay uses saved JPEGs; original tracking used decoded source frames before JPEG re-encoding.'},'observations':rows,'proposed_guard':{'max_gap_sim_s':.65,'max_rotation_rad':.18,'flagged_transitions':unsafe.tolist(),'flagged_transition_count':len(unsafe),'accepted_ids_crossing':sorted(p['track_id'] for p in landmarks if p['track_id'] in crossing),'all_tracks_crossing':len(crossing),'note':'Developmental policy after inspecting this mission; not a new held-out result.'},'elapsed_s':time.monotonic()-started}
(OUT/'outlier_report.json').write_text(json.dumps(report,indent=2))
panels=[]
for f,im in zip([a,b],images):
    row=next(r for r in rows if r['frame']==f)
    cv2.circle(im,tuple(np.round(row['observed']).astype(int)),10,(0,0,255),2)
    cv2.drawMarker(im,tuple(np.round(row['predicted']).astype(int)),(255,255,0),cv2.MARKER_CROSS,24,2)
    cv2.putText(im,f'frame {f} | red: recorded | cyan: reprojection',(15,520),cv2.FONT_HERSHEY_SIMPLEX,.65,(0,100,255),2)
    panels.append(im)
cv2.imwrite(str(OUT/'outlier_rgb_evidence.jpg'),np.vstack(panels),[cv2.IMWRITE_JPEG_QUALITY,92])
print(json.dumps({k:v for k,v in report.items() if k not in ['observations','proposed_guard']}),flush=True)
