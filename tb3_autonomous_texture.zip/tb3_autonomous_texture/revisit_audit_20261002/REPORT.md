# Post-mission audit: revisit consistency and temporal association failure

Date: 2026-10-02. Dataset: the completed 2026-10-01 autonomous development mission in the textured TurtleBot3 Waffle simulation. The original 4,020-landmark map and its reported test residuals are unchanged. This audit used recorded RGB frames, saved tracks, calibration and fused poses. It issued no robot-motion commands and consumed no depth, magnetometer, simulator pose or world geometry.

## Findings

The completed mission achieved its finite navigation/view-coverage criterion, but the sparse map still has measurable disagreement between revisits. Small within-track reprojection residuals alone did not establish global map consistency. A separate temporal-association failure was reproduced exactly and a guarded tracker passed a focused replay regression. Neither result establishes dense surface completeness or absolute metric accuracy.

## Reproduced outlier

The maximum reserved-pixel error, 264.9458448244 px, belongs to track 14326 at keyframe 170. Refitting its original block reproduced the same 308 accepted IDs and exactly the same coordinates and test errors on the same machine. This rules out a cache-placement or reporting discrepancy in this reproduction.

The transition from frame 170 to 171 spans 1.089 simulated seconds, approximately 17.48 degrees of camera rotation and 0.0794 m of estimated camera translation. The recorded pixel at frame 170 is (264, 110); the reconstructed feature projects to approximately (528.86, 103.34). At frame 171, the recorded and projected pixels agree within 0.25 px. The RGB contact sheet shows that similar-looking texture marks were associated across the large image displacement.

Replaying the original Lucas–Kanade settings on saved JPEGs recovered the stored next pixel to within about 0.01 px. The erroneous match still had a forward/backward discrepancy of only 0.0235 px and a photometric error of 0.706, so the existing checks accepted it. JPEG replay is not byte-identical to the original decoded stream, but it reproduces this association closely. Other scored tracks at frame 170 have low residuals, further supporting a local correspondence failure rather than a general failure of that camera pose.

The original maximum and all 9,859 reserved observations remain in the baseline. No outlier was deleted to improve a reported score.

## Revisit consistency

Candidate image pairs were selected by time separation (at least 40 simulated seconds), fused camera distance (at most 0.60 m), optical direction (at most 30 degrees) and available accepted landmarks. Greedy temporal spacing reduced 1,285 candidate image pairs to 31 evaluated pairs. RGB SIFT descriptors were compared at recorded training/validation pixels with mutual nearest-neighbor ratio below 0.70. Identical track IDs and overlapping temporal tracks were excluded. The inspected reserved test pixels were not used for these associations.

No 3D-distance gate, nearest-neighbor point-cloud association, ICP or coordinate alignment selected the pairs. A secondary two-view fundamental-matrix RANSAC check used a 2 px threshold, at least 12 image matches and image-coordinate spread above 40 px on both axes. Repeated image-pair support is reported separately. Each unordered landmark-ID pair contributes once to the metrics below.

| Candidate correspondence set | ID pairs | Median 3D separation | 90th percentile | Maximum |
| --- | ---: | ---: | ---: | ---: |
| RGB mutual-ratio matches | 162 | 8.80 cm | 15.89 cm | 154.03 cm |
| Also supported by image epipolar geometry | 89 | 8.10 cm | 13.99 cm | 18.35 cm |
| Also seen in multiple image pairs | 21 | 4.84 cm | 13.36 cm | 13.97 cm |
| Both additional checks | 19 | 4.60 cm | 13.43 cm | 13.97 cm |

The epipolar-supported set covers 178 distinct landmark IDs and four block pairs: 1/20, 2/20, 4/6 and 15/28. It does not cover the full 29-block reconstruction. Its median vertical separation is 0.00323 m, suggesting that much of the disagreement in this subset is horizontal. This is an internal agreement measure, not error against surveyed geometry. Shared pose priors, texture ambiguity, planar geometry and near-repeated viewpoints limit independence and reliability. Epipolar support does not certify a correct physical association; montage inspection is illustrative, not exhaustive human labeling.

## Retrospective translation diagnostic

After observing the aggregate discrepancy, a separate diagnostic tested constant displacement between block pairs. Within each of the four groups, unordered ID pairs were sorted using a fixed SHA256 key and alternated between fitting and evaluation. A componentwise median translation was fitted on the training pairs only. Forty-three evaluation pairs remained across the groups.

| Evaluation-pair statistic | Original coordinates | After diagnostic translation |
| --- | ---: | ---: |
| Median separation | 8.10 cm | 1.55 cm |
| 90th percentile | 13.88 cm | 5.28 cm |
| Maximum | 18.35 cm | 15.95 cm |

This reduction supports a systematic component to the disagreement. The remaining tail, especially for blocks 4/6, shows that translation alone is insufficient or some associations are wrong. Separate pairwise translations can also conflict: block 20 participates in two independently fitted groups. Therefore these transforms were not applied to the map, and they are not a solved global pose graph. The split was designed after inspecting the aggregate results and reuses the same mission and image neighborhoods; it is developmental evidence, not untouched validation or an independent trial.

## Guarded tracker candidate

`monocular_guarded.py` is a separate copy of the RGB node. Its `tracking_policy.py` restarts temporal tracks when the gap exceeds 0.65 simulated seconds, the relative fused-camera rotation exceeds 0.18 rad, or time/pose inputs are invalid. New observations receive new IDs; the old association is not repaired by silently changing its recorded pixels.

The integration replay invokes the candidate's actual image-processing method with recorded JPEGs and a mocked TF lookup, without starting a ROS node or publishing velocity. The failed 170→171 transition restarted tracking and seeded 207 new IDs. The regular 172→173 transition continued the original ID. Invalid-time and large-rotation checks also passed. The first test fixture incorrectly expected a dead one-view track to remain stored; it was corrected to assert the intended pruning behavior, and that test-harness failure log is retained.

The proposed guard flags 138 of 1,822 recorded transitions: 130 image gaps and eight rotations. Tracks for 1,513 of the original 4,020 accepted IDs cross at least one flagged transition. This is a potential fragmentation cost, not a prediction that all 1,513 points disappear: split segments may still triangulate. The thresholds were chosen after examining this mission, and the candidate has not been validated on a fresh trajectory. It was not launched in the completed ROS session and has not replaced the baseline node.

## Disposition and next engineering step

The audit is complete, and the baseline inputs and final cloud passed a before/after SHA256 preservation check. The robot remains in the previously stopped mission; no additional run was started. The current RViz map is still the baseline.

Before densification, the next engineering step is to build globally consistent cross-revisit visual constraints with robust association checks and a connected submap optimization, then evaluate them on a new run with a predeclared protocol. The guarded tracking policy needs that new-run coverage/cost evaluation as well. The present evidence does not justify promoting four independent pairwise translations to a whole-map correction.

## Reproduction and evidence

On the Dell, the source recordings and images remain under `/home/lpviana/tb3_autonomous_texture_20261001/output`. This audit resides in the sibling `revisit_audit_20261002` directory. Source hashes are in `revisit_summary.json` and `baseline_preservation.json`.

With the existing ROS Jazzy Python environment and dependencies, run `audit_revisits.py OUTPUT AUDIT_DIR`, `audit_outlier.py OUTPUT AUDIT_DIR`, `audit_translation.py AUDIT_DIR` and `test_guarded_tracking.py OUTPUT`. The outlier script instruments a copy of the original fit function in memory solely to expose fitted poses; it does not modify the fitting equations or write baseline outputs. The guarded node is a development candidate, not a drop-in mission launcher.

The portable archive includes the scripts, numerical reports, RGB evidence montages and figure. Full recorded JPEG sequences and MCAP payloads remain on the Dell; this archive is not a self-contained copy of the raw dataset.

## IMU role in the current implementation

The pipeline is cascaded rather than a jointly optimized visual-inertial estimator. `odometry.py` and `fusion_math.py` maintain an EKF state [x, y, yaw, forward velocity, yaw rate, gyro bias]. Wheel linear/angular velocities and the raw Z gyroscope update the filter. The estimated heading then affects integrated X/Y motion. LiDAR SLAM consumes this odometric transform and supplies map-frame correction; it does not directly subscribe to the IMU in this configuration.

Raw X/Y gyro and accelerometer gravity direction estimate online roll/pitch. Accelerometer magnitude also gates stationary updates; acceleration is not double-integrated for position. The final stable reconstruction explicitly flattens the initial poses to yaw-only orientation and fixed camera height before local bundle adjustment, so the online inertial tilt is not retained as a final-fit prior. Local bundle adjustment permits regularized six-parameter pose corrections, but does not use IMU preintegration or inertial factors. No magnetometer or `Imu.orientation` is used. These limits should be explicit in a paper describing sensor participation.
