"""Publication-style plot of measured internal consistency, not ground truth."""
import json,os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/tb3_audit_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
P=Path(__file__).resolve().parent
rows=json.loads((P/'revisit_matches.json').read_text());diag=json.loads((P/'translation_diagnostic.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(12,4.7),layout='constrained')
for selected,label,color in [(rows,'RGB candidates (162)','#9299a2'),([r for r in rows if r['epipolar_supported']],'Epipolar supported (89)','#166d87'),([r for r in rows if r['epipolar_supported'] and r['repeat_support']],'Also repeated in images (19)','#b05b36')]:
    x=np.sort([r['distance_m']*100 for r in selected]);axes[0].step(x,np.arange(1,len(x)+1)/len(x),where='post',label=label,color=color,lw=2)
axes[0].set(xscale='log',xlabel='Unaligned 3D separation (cm; log scale)',ylabel='Cumulative fraction of landmark-ID pairs',title='Agreement between revisits');axes[0].legend(loc='lower right',fontsize=8);axes[0].grid(alpha=.18)
lookup={tuple(sorted((r['track_a'],r['track_b']))):r for r in rows}
for g,color in zip(diag['groups'],['#166d87','#7e6aab','#b05b36','#4f8553']):
    if 'test_pairs' not in g:continue
    delta=[]
    for ids in g['test_pairs']:
        r=lookup[tuple(sorted(ids))];delta.append(np.array(r['delta_m'])*(1 if r['block_a']<r['block_b'] else -1))
    d=np.array(delta);before=np.linalg.norm(d,axis=1)*100;after=np.linalg.norm(d+g['translation_to_second_block_m'],axis=1)*100
    axes[1].scatter(before,after,c=color,s=30,label=f"Blocks {g['blocks'][0]}/{g['blocks'][1]}",edgecolors='white',linewidths=.4)
axes[1].plot([0,20],[0,20],'--',c='#777',lw=1);axes[1].set(xlim=(0,20),ylim=(0,20),xlabel='Original separation (cm)',ylabel='After fitted translation (cm)',title='43 evaluation pairs: translation diagnostic');axes[1].legend(fontsize=8);axes[1].grid(alpha=.18)
fig.suptitle('Internal consistency audit — sparse monocular map\nRetrospective, partial coverage; no ground-truth accuracy claim',fontsize=13)
fig.savefig(P/'audit_metrics.png',dpi=170);fig.savefig(P/'audit_metrics.pdf')
print('Audit figures saved')
