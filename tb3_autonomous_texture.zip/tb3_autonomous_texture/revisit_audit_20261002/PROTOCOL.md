# Post-mission revisit and outlier audit

Written before computing revisit residuals, 2026-10-02. This is an exploratory audit of a development mission, not a new independent validation set. The original fit, acceptance set and reserved-pixel results are frozen.

1. Inspect the worst held-out observation (track 14326, frame 170), original RGB frames, pose continuity and training support. Do not remove the held-out observation from the published baseline.
2. Select temporally separated image pairs using fused camera pose and accepted-track availability only: at least 40 simulated seconds apart, camera centers within 0.60 m, optical directions within 30 degrees, at least 12 accepted landmarks per frame. Greedily sample at most 80 pairs, spacing each endpoint by at least 3 s from previous pairs with a nearby opposite endpoint.
3. Compare RGB descriptors at recorded landmark pixels, using SIFT with a fixed 24-pixel keypoint size and angle 0 (approximately upright camera), mutual two-nearest-neighbor ratio below 0.70. No 3D landmark-distance gate or ICP registration selects correspondences. Reject identical track IDs and overlapping temporal tracks.
4. Use additional RGB views to check descriptor consistency, and two-view image geometry as a secondary correspondence check. Report raw matches as well as any geometry-supported subset. Aggregate each unordered landmark-ID pair once. Report distributions rather than claiming ground-truth accuracy; repeated texture can create false matches.
5. For a conservative image-geometry subset, apply a 2-pixel RANSAC fundamental-matrix threshold, requiring at least 12 matches and spatial spread across both image axes. This check is diagnostic, because planar scenes and nearly repeated camera poses can be degenerate.
6. Evaluate the pre-existing 3D coordinates without alignment. Report Euclidean and vertical differences, coverage of tested IDs and blocks, and the limitations of shared fused pose priors. Do not merge landmarks or change RViz automatically on the strength of nearest-neighbor similarity.
7. If a tracker defect is found, test a separately named correction on a copy. Results using these inspected frames are developmental, not untouched held-out validation.

## Translation diagnostic amendment

After observing aggregate revisit disagreement, test whether a constant block-pair displacement explains it. Use only the already reported epipolar-supported candidate pairs. For each block pair with at least 12 candidates, sort by SHA256 of unordered IDs plus a fixed audit seed; alternate training and evaluation items. Fit a componentwise median 3D translation on training only and report pre/post distances on evaluation. Do not apply it to the live map. This retrospective split is developmental and the shared image, pose and appearance-selection dependencies remain.

## Candidate tracking amendment

A separate copy of the RGB node resets temporal tracking after gaps above 0.65 simulated seconds or fused-camera rotation above 0.18 rad (and on invalid/non-monotonic input). These are development parameters motivated by the failed 1.089 s / 17.48 degree transition. Reset means starting new IDs, never relabeling a discarded test pixel as correct. The published baseline is immutable. This may fragment otherwise useful tracks; quantify affected transitions before a new mission. The candidate node is saved, not launched against the completed experiment.
