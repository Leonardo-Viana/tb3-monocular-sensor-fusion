# Autonomous monocular mapping mission

This version launches a bounded autonomous mission in the current textured TurtleBot3 Waffle Gazebo scene. See MISSION_PROTOCOL.md for frozen policy, stopping criteria and limitations.

## Verified final result (2026-10-02)

The mission finished on 2026-10-01 at 14:30:19 UTC with `reachable_view_coverage_complete`. The resumed segment covered 148/152 reachable lattice views (97.37%), reached 68 goals, returned within about 0.11 m of the estimated starting position, and stopped. It travelled an estimated 27.57 m in 1607.5 wall seconds. Nine goals failed. The preceding synchronous attempt is preserved separately (6 goals, 4.35 m, refinement timeout); these are segments of the same development mission, not independent trials.

The final fit accepted 4,020 sparse RGB landmark IDs from 1,822 keyframes. The recorded keyframe file contains 1,823 frames, so one later frame is outside the final fit. The 9,859 reserved pixel observations have median error 0.2807 px and 90th percentile 0.8547 px. There are 23 errors above 3 px and one above 8 px, with maximum 264.9458 px. Two accepted IDs have no scored test observations. Three optimization blocks did not converge and contributed no accepted points. No test outlier was removed to improve these reported numbers.

This is successful bounded autonomous exploration and sparse reconstruction, not proof of complete surfaces, a dense mesh, globally accurate geometry, or uniquely associated physical landmarks. View coverage is a finite pose-and-heading lattice metric. Pixel consistency is not a metric ground-truth accuracy measure.

At the Oct 2 readback, Gazebo reported `paused: true`, the command audit ended at zero linear and angular velocity, and exactly one RViz process was alive. See `output/final_verification.json`.

The portable archive contains source, final PLY and numerical evidence, a planar occupancy snapshot, the command audit, figures and English reports. The approximately 4.84 GB of raw MCAP data and full tracking inputs remain on the Dell under the recorded paths. Two recording segments were traversed, counts matched bag metadata, and endpoint RGB images decoded; this does not establish zero acquisition loss. File hashes and topic counts are in `output/FINAL_REPORT.json`.

Start with `output/FINAL_REPORT.md`, `output/final_verification.json`, and `mission_map.png`. `output/async_run_manifest.json` is the final supervisor record; `output/supervisor_status.json` describes the preserved first attempt.

Live project on the Dell: `/home/lpviana/tb3_autonomous_texture_20261001`.

- `output/autonomy_status.json`: state, coverage, reached/failed goals and stopping reason.
- `output/stable/`: cached rigid submaps, PLY, reserved-pixel metrics and anchors.
- `output/raw/`: original permitted sensor recording, split into MCAP files.
- `output/map_snapshot.json`: derived planar LiDAR occupancy grid.
- `output/supervisor_status.json`: overall termination state.
- `mission.rviz`: the single live visualization. Before the first refinement, the cloud is explicitly provisional.

To request a stop on the Dell: `touch /home/lpviana/tb3_autonomous_texture_20261001/output/STOP`. The controller stops and saves. SIGINT to the controller also requests a stop. Gazebo pause stops simulated motion; loss of simulated sensor updates then terminates the mission.

Do not rerun the supervisor over an existing run. It preserves prior results and refuses that action. The launcher expects the existing textured Gazebo server in partition `tb3_texture_pilot_20260929`; it does not create or modify scene geometry. Source ROS Jazzy before launching.

Maximum mission wall budget is 30 minutes, with a return attempt near the end. A finite reachable-view completion condition is not a certificate of full dense 3D surface coverage. Untextured and occluded surfaces may remain absent. No compass, RGB-D or simulator ground truth is consumed by the estimator.

## Post-mission audit (2026-10-02)

See `revisit_audit_20261002/REPORT.md` for the completed outlier investigation and RGB-based revisit consistency audit, including candidate associations, residual tails, a retrospective translation diagnostic and a separately tested temporal-tracking guard. The original map and source data are unchanged. No new mission was launched, and the guard has not been promoted to the live stack.

The guarded candidate successfully prevents the reproduced 170-to-171 track swap in JPEG replay, with a measurable potential fragmentation cost. Internal revisit agreement remains imperfect; the audit is not a global accuracy or dense-completion certificate. `revisit_audit_20261002/audit_metrics.png` summarizes the measured distributions.
