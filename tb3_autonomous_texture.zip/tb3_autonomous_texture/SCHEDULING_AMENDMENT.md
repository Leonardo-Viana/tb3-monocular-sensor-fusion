# Scheduling amendment, 1 October 2026

The synchronous first attempt completed six goals and approximately 4.35 m before its first 200-second reconstruction deadline was exceeded. No navigation clearance or sensor failure triggered this stop. The first converged block contained 536 accepted points; that block was cached. The synchronous attempt and logs are retained.

The resumed controller keeps the same live wheel/IMU and LiDAR-SLAM session, consumes immutable saved snapshots, and refines in a separate process while motion proceeds. Fit code, numerical thresholds and reserved-pixel decisions are unchanged. Previous points and sensor recordings are retained. This is an operational amendment in a development mission, not a new matched experimental replicate. An independent full completion claim is still unavailable.

The synchronous termination pass subsequently completed all three blocks using one cached block. It produced 1,020 accepted points from 152 keyframes, with 2,683 reserved observations (median 0.329 px, p90 0.937 px, maximum 5.710 px). Total attempt wall time was about 501.5 s. These points are preserved when autonomous exploration resumes.
