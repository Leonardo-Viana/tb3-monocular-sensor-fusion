# Autonomous textured-scene mapping: execution report

Generated 2026-10-01T14:30:40.294692+00:00.

## Actual terminal state

The resumed controller stopped with reason **reachable_view_coverage_complete**. It reached 68 goals and travelled approximately 27.573 m according to fused map-frame pose increments. This is not ground-truth distance. It recorded 9 failed goals and 0 limited recovery attempts. The supervisor's separate manifest records any infrastructure error.

- Preserved attempt: refinement_timeout; 6 goals; 4.349 m; 501.5 s.

## Last completed reconstruction

The last completed fit contains 4020 accepted sparse RGB landmark IDs from 1822 keyframes. Reserved pixels: {'n': 9859, 'median': 0.28067136045692614, 'p90': 0.854659685868618, 'max': 264.9458448244183}. Aggregate pixel gate: True. Consult the numerical evidence for full tails, unscored observations and nonconverged blocks. Counts may include multiple IDs for one physical feature. Reconstruction may lag the newest acquired frame if a final job failed or timed out; the keyframe file and fit summary preserve both sizes.

Planner metrics: {"frontier_groups": 0, "frontier_cells": 0, "view_goals_total": 152, "view_goals_covered": 148, "view_goals_blocked": 3, "view_coverage": 0.9736842105263158, "free_area_m2": 19.59519912402631, "reachable_area_m2": 8.235199631857876, "reason": "home_reached"}. Coverage refers to a finite reachable camera-view lattice, not dense surface completeness. Full 3D completion and absolute metric accuracy are **not established**.

The estimator consumed RGB image rays, wheel velocity, raw gyro/accelerometer, and 2D LiDAR pose support. No RGB-D, compass, IMU orientation field or simulator/world geometry was an estimator input. Historical datasets were preserved. The first synchronous processing deadline and the asynchronous scheduling amendment are part of the experimental record, not silently discarded failures.

## Recordings

2 MCAP recording segments were traversed. All per-topic count comparisons passed: True. First and last RGB frames were decoded for every segment. Raw data remain at the paths and hashes in FINAL_REPORT.json; successful traversal is not proof of zero acquisition loss.

One RViz is used for the live/saved mission display. The simulator is requested to pause on supervisor termination. The command audit retains final observed velocity commands. See the audit and supervisor manifest rather than inferring robot state from this report alone.

This is a development mission with a scheduling amendment, not an independent controlled replicate of the uniform/textured pilot. No publication or public upload was performed.

## Independent final readback, 2026-10-02

The simulator stats topic reported `paused: true`. Exactly one RViz process remained (PID 80500). The final command audit recorded zero linear and angular velocity. The last completed fit used 1,822 of 1,823 captured keyframes. This is a one-frame lag, not an inferred complete use of all recorded frames.

Of 9,859 reserved test observations, 23 exceed 3 px and one exceeds 8 px (264.9458 px maximum). Two accepted landmark IDs have no scored test observation. Blocks 12, 21 and 22 did not converge and yielded no accepted points. These exclusions and the extreme held-out residual remain in the evidence; the aggregate gate must not be interpreted as every point being correct.

The saved figure displays all 4,020 accepted RGB landmark IDs and the derived planar LiDAR occupancy; it does not extrude occupied cells into 3D surfaces. The original RGB colors are retained. Full raw recordings remain on the Dell; the portable archive includes their hashes and metadata rather than the MCAP payloads.
