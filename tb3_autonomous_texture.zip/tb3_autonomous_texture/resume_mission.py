"""Resume the SAME live odometry/SLAM session after the synchronous fit timeout."""
import os,time,json,signal,subprocess,shutil,hashlib
from pathlib import Path
from launch_mission import ROOT,OUT,ENV,TOPICS,stop,pause

def main():
 old=json.loads((OUT/'pids.json').read_text());stamp=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime());history=OUT/'attempts'/('synchronous_'+stamp);history.mkdir(parents=True,exist_ok=False)
 for name in ['autonomy_status.json','supervisor_status.json','preflight.json','pids.json','run_started.json','autonomy.log','autonomy_refine.log','mission_audit.jsonl']:
  p=OUT/name
  if p.exists():shutil.copy2(p,history/name)
 for key,needle in [('odometry','odometry.py'),('slam','slam_toolbox')]:
  p=Path(f'/proc/{old[key]}/cmdline')
  if not p.exists() or needle not in p.read_bytes().decode(errors='ignore'):raise RuntimeError('Base pose session changed; cannot resume')
 # Check command owner has terminated before any new controller can be launched.
 if Path(f"/proc/{old['autonomy']}/stat").exists() and Path(f"/proc/{old['autonomy']}/stat").read_text().split(') ')[1].split()[0]!='Z':raise RuntimeError('Previous controller still alive')
 pids=dict(old);procs={};manifest={'start_utc':stamp,'amendment':'Asynchronous fitting of immutable snapshots; same estimator and pixel thresholds','preserved_attempt':str(history),'same_live_fusion_pids':{k:old[k] for k in ['odometry','slam']},'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},'state':'starting'}
 (OUT/'async_run_manifest.json').write_text(json.dumps(manifest,indent=2))
 def launch(name,cmd):
  p=subprocess.Popen(cmd,env=ENV,stdout=open(OUT/(name+'_resume.log'),'a'),stderr=subprocess.STDOUT,start_new_session=True);procs[name]=p;pids[name]=p.pid;(OUT/'pids.json').write_text(json.dumps(pids));return p
 args=['--ros-args','-p','use_sim_time:=true']
 try:
  launch('vision',['python3',str(ROOT/'monocular.py'),*args]);launch('record',['ros2','bag','record','-s','mcap','-o',str(OUT/('raw_resume_'+stamp)),'--use-sim-time','--max-cache-size','16777216','--max-bag-size','1000000000','--qos-profile-overrides-path',str(ROOT/'record_qos.yaml'),'--topics',*TOPICS])
  pause(False)
  r=subprocess.run(['python3',str(ROOT/'probe.py')],env=ENV,capture_output=True,text=True,timeout=20);(OUT/'resume_preflight.json').write_text(r.stdout);d=json.loads(r.stdout.strip().splitlines()[-1])
  if any(d.get('counts',{}).get(t,0)<1 for t in ['/scan','/odom','/imu','/camera/image_raw/compressed','/mono/map']) or 'pose' not in d or d.get('publishers',{}).get('/cmd_vel'):raise RuntimeError('Resume preflight failed')
  controller=launch('autonomy',['python3',str(ROOT/'autonomy_async.py'),'--seconds','1800',*args]);manifest['state']='exploring';(OUT/'async_run_manifest.json').write_text(json.dumps(manifest,indent=2));print('RESUMED_AUTONOMY',controller.pid,flush=True)
  deadline=time.monotonic()+3360
  while controller.poll() is None and time.monotonic()<deadline:
   if procs['record'].poll() is not None:raise RuntimeError('Recorder exited')
   time.sleep(1)
  if controller.poll() is None:raise RuntimeError('Supervisor deadline')
  manifest['state']='stopped';manifest['result']=json.loads((OUT/'autonomy_status.json').read_text())
 except BaseException as e:manifest['state']='stopped_error';manifest['exception']=repr(e);raise
 finally:
  stop(procs.get('autonomy'),30);stop(procs.get('vision'),20);stop(procs.get('record'),30);pause(True);manifest['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(OUT/'async_run_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'state':manifest['state'],'reason':manifest.get('result',{}).get('reason'),'exception':manifest.get('exception')}),flush=True)
if __name__=='__main__':main()
