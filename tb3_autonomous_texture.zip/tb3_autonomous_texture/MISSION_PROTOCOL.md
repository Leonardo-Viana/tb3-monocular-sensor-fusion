# Autonomous textured-scene mission — 1 October 2026

Prospective engineering run following the completed single-pair texture pilot. It is not an additional matched experimental replicate.

The user authorizes autonomous motion in the existing Gazebo TurtleBot3 Waffle scene and requests one RViz instance. Historical runs remain unchanged. A new ROS map and reconstruction session is created in its own project directory; historical camera poses and points are not merged into it.

Permitted estimator inputs: RGB image rays and camera calibration, wheel velocities, raw gyro/accelerometer, 2D LiDAR SLAM. No RGB-D, magnetometer, IMU orientation field, simulator pose or scene geometry is consumed by exploration/reconstruction.

The planner uses reachable frontiers in the live LiDAR occupancy map, followed by a 0.6 m lattice of camera views in eight headings. Nominal speeds are limited to 0.085 m/s and 0.32 rad/s. Command publication is capped at 20 Hz with an immediate zero-command exception. A separate process watchdog stops on stale heartbeat or owner death. Sensor freshness, live LiDAR clearance, 500 MiB available memory, 3 GiB disk reserve, maximum 5,500 keyframes and an 1,800 s mission wall budget are enforced. A supervisor imposes an additional finite wall deadline. No online parameter tuning against withheld pixel errors is planned.

The robot pauses to save/refine after six reached goals and at termination. The existing stable RGB local-submap algorithm and pixel thresholds are unchanged. Numerical block fits are cached only when tracks, referenced raw poses, timestamps, calibration and method hashes match; graph revisions place each cached submap rigidly. Cached outputs are saved atomically per generation. The initial RViz point layer is explicitly provisional until the first refinement generation is available.

Stop reasons distinguish reachable-view coverage, exhausted reachable views, resource limits, missing sensors, blocked paths and user interruption. View coverage is a finite planning criterion, not proof of complete or dense 3D surface reconstruction. Blocked/inaccessible areas and monocular texture/occlusion gaps remain limitations.

Raw bags include RGB, calibration, scan, IMU, wheel odometry, joints, clock, TF and commands, split at 1 GB. Automatic stop leaves the simulation paused and one RViz with saved/current results. `output/STOP` or SIGINT requests termination. Process/source manifests and mission progress are retained for the eventual English paper.

Preflight validation: collision-inflated path and completion logic tests passed; a repeated offline reconstruction of the historical uniform run accepted the same 19 landmark IDs, and a subsequent identical-input pass reused all three cached blocks. Small numerical differences from the historical fit across host/library execution are not treated as new experimental results. An independent watchdog test runs in a separate ROS domain before movement.
