"""Scientific figure from saved estimated points and derived LiDAR occupancy."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output'
pts=json.loads((OUT/'stable/stable_landmarks.json').read_text());s=json.loads((OUT/'autonomy_status.json').read_text());m=json.loads((OUT/'map_snapshot.json').read_text());xyz=np.array([p['xyz'] for p in pts]);rgb=np.array([p['rgb'] for p in pts])/255.;grid=np.array(m['data']).reshape(m['height'],m['width']);yy,xx=np.where(grid>=65);x=(xx+.5)*m['resolution']+m['position'][0];y=(yy+.5)*m['resolution']+m['position'][1]
fig=plt.figure(figsize=(12,6),layout='constrained');ax=fig.add_subplot(1,2,1,projection='3d');ax.scatter(x,y,np.zeros_like(x),s=2,c='#728da0',alpha=.3);ax.scatter(*xyz.T,c=rgb,s=3,depthshade=False);ax.set(xlabel='x (m)',ylabel='y (m)',zlabel='z (m)',title=f'{len(pts):,} accepted sparse RGB landmark IDs');ax.view_init(35,-75);ax.set_box_aspect((1,1,.4));ax.set_zlim(-.15,1.3)
ax=fig.add_subplot(1,2,2);extent=[m['position'][0],m['position'][0]+m['width']*m['resolution'],m['position'][1],m['position'][1]+m['height']*m['resolution']];ax.imshow(np.ma.masked_where(grid<0,grid),origin='lower',extent=extent,cmap='Greys',vmin=0,vmax=100,alpha=.65);ax.scatter(xyz[:,0],xyz[:,1],s=4,c='#196d84',alpha=.6,label='RGB landmarks (top view)');pos=s['current_position'];ax.scatter(*pos,s=110,marker='*',c='#c05c32',edgecolor='white',label='Last robot position');ax.set(xlabel='x (m)',ylabel='y (m)',aspect='equal',title=f"Reachable-view coverage: {100*s['map_metrics']['view_coverage']:.1f}%");ax.legend(loc='lower right',fontsize=8)
fig.suptitle('Autonomous monocular mapping — final development mission\nPlanar LiDAR supports pose and navigation; 3D points come from RGB rays',fontsize=13);fig.savefig(ROOT/'mission_map.png',dpi=160);fig.savefig(ROOT/'mission_map.pdf');print('figure saved')
