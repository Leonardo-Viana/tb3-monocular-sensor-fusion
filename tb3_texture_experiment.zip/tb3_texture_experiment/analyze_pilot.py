"""Descriptive post-pilot analysis; never modifies fits or selects landmarks."""
from pathlib import Path
import json,collections
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'paper';OUT.mkdir(exist_ok=True)
rows={};points={};errors={};motions={}
for condition in ['uniform','textured']:
 tr=ROOT/'runs'/f'{condition}_seed23_r01';s=json.loads((tr/'stable/validation.json').read_text());p=json.loads((tr/'stable/stable_landmarks.json').read_text());m=json.loads((tr/'pipeline/output/motion.json').read_text());bag=json.loads((tr/'bag_validation.json').read_text());resources=[json.loads(l) for l in (tr/'resources.jsonl').read_text().splitlines()];tracks=json.loads((tr/'pipeline/output/tracks.json').read_text())
 points[condition]=p;errors[condition]=np.array([e for pt in p for e in pt['test_errors_px']]);motions[condition]=m
 rows[condition]={'accepted_landmarks':s['accepted_landmarks'],'above_0_15m_landmarks':sum(pt['xyz'][2]>.15 for pt in p),'frames':s['frames'],'retained_tracks':s['input_tracks'],'retained_track_length_median':float(np.median([len(t['obs']) for t in tracks.values()])),'test_pixels':s['test_pixels'],'test_pixels_over_8':s['test_pixels_over_8px'],'dataset_gate':s['dataset_pixel_gate_pass'],'reconstruction_wall_s':s['duration_s'],'motion_wall_s':m['wall_seconds'],'wheel_distance_m':m['wheel_distance_m'],'motion_reason':m['reason'],'max_stack_pss_mib':max(x['pss_bytes_sum'] for x in resources)/2**20,'max_stack_rss_sum_mib':max(x['rss_bytes_sum'] for x in resources)/2**20,'min_host_available_mib':min(x['host_available_bytes'] for x in resources)/2**20,'max_host_swap_used_mib':max(x['host_swap_used_bytes'] for x in resources)/2**20,'bag_size_mib':bag['bag_bytes']/2**20,'rgb_messages':bag['topics']['/camera/image_raw/compressed'],'bag_verified':bag['matches_metadata'],'bag_message_count':bag['readable_messages'],'bag_sim_duration_s':bag['stamp_duration_s'],'cmd_messages_per_bag_sim_second':bag['topics']['/cmd_vel']/bag['stamp_duration_s'],'test_pixels_over_8_fraction':s['test_pixels_over_8px']/s['test_pixels']['n']}
# Identical command schedule, near-identical wheel travel. Neither proves same true pose.
comparison={'landmark_ratio':rows['textured']['accepted_landmarks']/rows['uniform']['accepted_landmarks'],'wheel_distance_absolute_difference_m':abs(rows['textured']['wheel_distance_m']-rows['uniform']['wheel_distance_m']),'same_schedule':motions['uniform']['schedule']==motions['textured']['schedule'],'n_runs_per_condition':1,'randomized_order':False,'ground_truth_accuracy_measured':False,'rows':rows}
(OUT/'pilot_results.json').write_text(json.dumps(comparison,indent=2))
plt.rcParams.update({'font.size':10,'axes.titlesize':12,'figure.facecolor':'white'})
fig=plt.figure(figsize=(12,8),layout='constrained')
allxyz=np.array([p['xyz'] for pts in points.values() for p in pts]);mins=allxyz.min(0);maxs=allxyz.max(0)
for j,c in enumerate(['uniform','textured']):
 ax=fig.add_subplot(2,2,j+1);im=Image.open(ROOT/'runs'/f'{c}_seed23_r01/pipeline/output/frames/00000.jpg');ax.imshow(im);ax.axis('off');ax.set_title(c.title()+' — first original RGB view')
 ax=fig.add_subplot(2,2,j+3,projection='3d');xyz=np.array([p['xyz'] for p in points[c]]);rgb=np.array([p['rgb'] for p in points[c]])/255.;ax.scatter(*xyz.T,c=rgb,s=12,edgecolors='#3c4651',linewidths=.15,depthshade=False);ax.set(xlim=(mins[0]-.1,maxs[0]+.1),ylim=(mins[1]-.1,maxs[1]+.1),zlim=(-.1,1),xlabel='x (m)',ylabel='y (m)',zlabel='z (m)');ax.view_init(25,-65);ax.set_title(f"{len(xyz)} accepted RGB-triangulated landmarks");ax.set_box_aspect((3,3,1.2))
fig.suptitle('Texture pilot: one run per condition, identical geometry and command schedule\nSparse estimated geometry; absolute metric accuracy not established',fontsize=13)
fig.savefig(OUT/'pilot_comparison.png',dpi=150);fig.savefig(OUT/'pilot_comparison.pdf');plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.7),layout='constrained')
for c,color in [('uniform','#ad5931'),('textured','#176981')]:
 e=np.sort(errors[c]);ax.step(e,np.arange(1,len(e)+1)/len(e),where='post',label=f'{c.title()} (n={len(e)} correlated test pixels)',color=color,lw=2)
ax.set_xscale('log');ax.set(xlabel='Reserved-observation reprojection error (pixels, log scale)',ylabel='Empirical cumulative fraction',ylim=(0,1.02),title='Within-track reserved pixels — not independent repeated experiments');ax.axvline(8,color='grey',ls=':',lw=1);ax.legend(loc='lower right');ax.grid(alpha=.2);fig.savefig(OUT/'test_error_ecdf.png',dpi=150);fig.savefig(OUT/'test_error_ecdf.pdf');plt.close(fig)
print(json.dumps(comparison,indent=2))
