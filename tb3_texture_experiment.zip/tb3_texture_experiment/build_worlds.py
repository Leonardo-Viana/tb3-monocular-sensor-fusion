"""Build a matched uniform/textured scene pair. Authoring only, never estimator input."""
from pathlib import Path
import copy,hashlib,json,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'source';OUT=ROOT/'worlds'
NS='http://www.collada.org/2005/11/COLLADASchema'

def sub(parent,tag,text=None,**attr):
 n=ET.SubElement(parent,tag,attr)
 if text is not None:n.text=str(text)
 return n

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def mapped_mesh(src,dst):
 ET.register_namespace('',NS);d=ET.parse(src);n={'c':NS}
 for mesh in d.findall('.//c:mesh',n):
  sources={s.get('id'):s for s in mesh.findall('c:source',n)};v=mesh.find('c:vertices',n)
  ps=v.find("c:input[@semantic='POSITION']",n).get('source')[1:]
  positions=np.fromstring(sources[ps].find('c:float_array',n).text,sep=' ').reshape(-1,3)
  ni=v.find("c:input[@semantic='NORMAL']",n)
  normals=np.fromstring(sources[ni.get('source')[1:]].find('c:float_array',n).text,sep=' ').reshape(-1,3)
  uv=[]
  for p,normal in zip(positions,normals):
   axes=[a for a in range(3) if a!=np.argmax(abs(normal))]
   # Coordinates used only to paint existing surfaces, not for localization.
   uv.append(p[axes]/200.)
  sid=ps+'_uv';s=sub(mesh,'{'+NS+'}source',id=sid);fa=sub(s,'{'+NS+'}float_array',' '.join(map(str,np.array(uv).ravel())),id=sid+'_data',count=str(2*len(uv)))
  tc=sub(s,'{'+NS+'}technique_common');acc=sub(tc,'{'+NS+'}accessor',source='#'+fa.get('id'),count=str(len(uv)),stride='2');sub(acc,'{'+NS+'}param',name='S',type='float');sub(acc,'{'+NS+'}param',name='T',type='float')
  for tri in mesh.findall('c:triangles',n):
   inputs=tri.findall('c:input',n);stride=max(int(i.get('offset','0')) for i in inputs)+1
   idx=np.fromstring(tri.find('c:p',n).text,sep=' ',dtype=int).reshape(-1,stride);vo=int(next(i for i in inputs if i.get('semantic')=='VERTEX').get('offset','0'))
   sub(tri,'{'+NS+'}input',semantic='TEXCOORD',source='#'+sid,offset=str(stride),set='0')
   tri.find('c:p',n).text=' '.join(map(str,np.c_[idx,idx[:,vo]].ravel()))
 d.write(dst,encoding='utf-8',xml_declaration=True)
 # All original geometry/normals and indices remain byte-for-byte numerically equal.
 a=ET.parse(src);b=ET.parse(dst)
 for old in a.findall('.//c:float_array',n):
  new=b.find(".//c:float_array[@id='"+old.get('id')+"']",n)
  assert old.text==new.text

def floor_mesh(path):
 # Same 100 x 100 m visual plane, with UV coordinates repeating every 2 m.
 path.write_text('''<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1"><asset><unit name="meter" meter="1"/><up_axis>Z_UP</up_axis></asset><library_geometries><geometry id="floor"><mesh>
 <source id="pos"><float_array id="pos_data" count="12">-50 -50 0 50 -50 0 50 50 0 -50 50 0</float_array><technique_common><accessor source="#pos_data" count="4" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source>
 <source id="uv"><float_array id="uv_data" count="8">0 0 50 0 50 50 0 50</float_array><technique_common><accessor source="#uv_data" count="4" stride="2"><param name="S" type="float"/><param name="T" type="float"/></accessor></technique_common></source>
 <vertices id="verts"><input semantic="POSITION" source="#pos"/></vertices><triangles count="2"><input semantic="VERTEX" source="#verts" offset="0"/><input semantic="TEXCOORD" source="#uv" offset="1" set="0"/><p>0 0 1 1 2 2 0 0 2 2 3 3</p></triangles></mesh></geometry></library_geometries><library_visual_scenes><visual_scene id="scene"><node><instance_geometry url="#floor"/></node></visual_scene></library_visual_scenes><scene><instance_visual_scene url="#scene"/></scene></COLLADA>''')

def paint(seed,path):
 rng=np.random.default_rng(seed);im=Image.new('L',(512,512),185);dr=ImageDraw.Draw(im)
 for _ in range(220):
  x,y=rng.integers(0,500,2);w,h=rng.integers(7,42,2);gray=int(rng.choice([45,85,120,155,210,240]));box=(int(x),int(y),int(min(511,x+w)),int(min(511,y+h)))
  if rng.random()<.7:dr.rectangle(box,fill=gray)
  else:dr.ellipse(box,fill=gray)
 im=im.convert('RGB');im.save(path);return int(np.round(np.asarray(im).mean()))

def build():
 OUT.mkdir(exist_ok=True);(OUT/'textures').mkdir(exist_ok=True);(OUT/'meshes').mkdir(exist_ok=True)
 for name in ['wall.dae','hexagon.dae']:mapped_mesh(SRC/name,OUT/'meshes'/name)
 floor_mesh(OUT/'meshes/floor.dae')
 base=ET.parse(SRC/'original.world').getroot();w=base.find('world');w.set('name','texture_trial')
 for x in list(w):
  if x.tag in ['include','model']:w.remove(x)
 ground=copy.deepcopy(ET.parse(SRC/'ground.sdf').find('model'));g=ground.find('.//visual/geometry');g.clear();m=sub(g,'mesh');sub(m,'uri',(OUT/'meshes/floor.dae').resolve())
 w.append(ground)
 for child in ET.parse(SRC/'sun.sdf').getroot():w.append(copy.deepcopy(child))
 scene=copy.deepcopy(ET.parse(SRC/'world_model.sdf').find('model'));scene.set('name','turtlebot3_world')
 for v in scene.findall('.//visual'):
  v.set('name','painted_'+v.get('name'))
  for uri in v.findall('.//mesh/uri'):uri.text=str((OUT/'meshes'/Path(uri.text).name).resolve())
 # Collision paths still reference the unmodified upstream assets.
 w.append(scene)
 robot=copy.deepcopy(ET.parse(SRC/'robot.sdf').find('model'));robot.set('name','waffle');pose=robot.find('pose')
 if pose is None:pose=sub(robot,'pose')
 pose.text='-2.0 -0.5 0.01 0 0 0';w.append(robot)
 visuals=ground.findall('.//visual')+scene.findall('.//visual');means=[]
 for i,v in enumerate(visuals):
  mean=paint(20260929+i,OUT/'textures'/f'textured_{i:02d}.png');means.append(mean)
  Image.new('RGB',(512,512),(mean,)*3).save(OUT/'textures'/f'uniform_{i:02d}.png')
  mat=v.find('material')
  if mat is None:mat=sub(v,'material')
  # Neutral modulation makes the albedo visible even on originally black walls.
  # Both conditions receive exactly the same material values.
  for tag,value in [('ambient','1 1 1 1'),('diffuse','1 1 1 1'),('specular','0 0 0 1')]:
   node=mat.find(tag)
   if node is None:node=sub(mat,tag)
   node.text=value
  old=mat.find('pbr')
  if old is not None:mat.remove(old)
  pbr=sub(mat,'pbr');metal=sub(pbr,'metal');sub(metal,'metalness',0);sub(metal,'roughness',1)
  sub(metal,'albedo_map',str((OUT/'textures'/f'uniform_{i:02d}.png').resolve()))
 for condition in ['uniform','textured']:
  r=copy.deepcopy(base)
  for uri in r.findall('.//albedo_map'):uri.text=uri.text.replace('uniform_',condition+'_')
  ET.indent(r);ET.ElementTree(r).write(OUT/(condition+'.sdf'),encoding='utf-8',xml_declaration=True)
 a=(OUT/'uniform.sdf').read_text();b=(OUT/'textured.sdf').read_text();assert a==b.replace('textured_','uniform_')
 col=''.join(ET.tostring(x,encoding='unicode') for x in base.findall('.//collision'))
 sensors=''.join(ET.tostring(x,encoding='unicode') for x in base.findall('.//sensor'))
 manifest={'conditions':['uniform','textured'],'difference':'albedo texture file only; geometry, sensors, lighting and physics identical',
  'uniform_control':'Mean-matched uniform textures through the same PBR shader; not bit-identical to the historic unmodified scene',
  'texture_seed':20260929,'texture_resolution':[512,512],'textured_visuals':len(visuals),'texture_means':means,
  'collision_sha256':hashlib.sha256(col.encode()).hexdigest(),'sensor_sha256':hashlib.sha256(sensors.encode()).hexdigest(),
  'sensors':[(x.get('name'),x.get('type')) for x in base.findall('.//sensor')],
  'common_changes':'UVs added to existing visual meshes without altering original vertex arrays; floor visual becomes an equivalent planar quad; collision meshes unchanged',
  'authoring_isolated_from_estimator':True,'files':{str(p.relative_to(ROOT)):sha(p) for p in OUT.rglob('*') if p.is_file()}}
 (ROOT/'scene_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
if __name__=='__main__':build()
