"""Sequential paired pilot, isolated ROS domain and Gazebo transport partition.
Scene paths are consumed only by the simulator. Estimator/controller receive topics.
"""
import os,sys,time,json,hashlib,signal,shutil,subprocess,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DOMAIN='73';PARTITION='tb3_texture_pilot_20260929'
TOPICS=['/camera/image_raw/compressed','/camera/camera_info','/scan','/imu','/odom','/joint_states','/tf','/tf_static','/clock','/cmd_vel']
ENV=dict(os.environ,ROS_DOMAIN_ID=DOMAIN,ROS_LOCALHOST_ONLY='1',GZ_PARTITION=PARTITION,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',TURTLEBOT3_MODEL='waffle')
ENV['GZ_SIM_RESOURCE_PATH']=str(Path('/opt/ros/jazzy/share/turtlebot3_gazebo/models'))+os.pathsep+ENV.get('GZ_SIM_RESOURCE_PATH','')

def kill(p,timeout=8):
 if p is None or p.poll() is not None:return
 os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=4)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()

def one(condition):
 trial=ROOT/'runs'/f'{condition}_seed23_r01';trial.mkdir(parents=True,exist_ok=False)
 pipe=trial/'pipeline';shutil.copytree(ROOT/'pipeline',pipe);out=pipe/'output';out.mkdir();procs={};manifest={};args=['--ros-args','-p','use_sim_time:=true']
 def launch(name,cmd):
  p=subprocess.Popen(cmd,env=ENV,stdout=open(trial/(name+'.log'),'w'),stderr=subprocess.STDOUT,start_new_session=True);procs[name]=p;manifest[name]=p.pid;(trial/'pids.json').write_text(json.dumps(manifest));return p
 record=None;motion=None;success=False
 config={'condition':condition,'seed':23,'ros_domain_id':int(DOMAIN),'gz_partition':PARTITION,'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'world_file':str(ROOT/'worlds'/(condition+'.sdf')),'commands':{},'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pipe.iterdir() if p.is_file()},'host':platform.platform(),'processing_host':'same Dell Vostro as simulation'}
 (trial/'run_manifest.json').write_text(json.dumps(config,indent=2))
 try:
  server=launch('server',['gz','sim','-r','-s','-v','2','--seed','23',str(ROOT/'worlds'/(condition+'.sdf'))])
  launch('telemetry',['python3',str(pipe/'telemetry.py'),str(trial)])
  launch('bridge',['ros2','run','ros_gz_bridge','parameter_bridge','--ros-args','-p','config_file:=/opt/ros/jazzy/share/turtlebot3_gazebo/params/turtlebot3_waffle_bridge.yaml'])
  launch('image',['ros2','run','ros_gz_image','image_bridge','/camera/image_raw'])
  launch('odometry',['python3',str(pipe/'odometry.py'),*args])
  launch('slam',['ros2','run','slam_toolbox','async_slam_toolbox_node','--ros-args','-r','__node:=mono_slam','--params-file',str(pipe/'slam.yaml'),'-r','map:=/mono/map','-r','map_metadata:=/mono/map_metadata','-r','pose:=/mono/laser_pose','-r','/slam_toolbox/graph_visualization:=/mono/graph','-r','/mono_slam/graph_visualization:=/mono/graph'])
  for transition in ['configure','activate']:
   ok=False
   for attempt in range(12):
    cmd=['ros2','lifecycle','set','/mono_slam',transition,'--no-daemon']
    # lifecycle CLI has no portable --no-daemon switch; domain env isolates discovery.
    cmd=cmd[:-1]
    r=subprocess.run(cmd,env=ENV,capture_output=True,text=True,timeout=10)
    if 'successful' in r.stdout:ok=True;break
    if server.poll() is not None:raise RuntimeError('Simulator exited before lifecycle initialization')
    time.sleep(1)
   if not ok:raise RuntimeError('Lifecycle failed: '+r.stdout+r.stderr)
  vision=launch('vision',['python3',str(pipe/'monocular.py'),*args])
  record=launch('record',['ros2','bag','record','-s','mcap','-o',str(trial/'raw'),'--use-sim-time','--max-cache-size','16777216','--qos-profile-overrides-path',str(ROOT/'record_qos.yaml'),'--topics',*TOPICS])
  # Require decoded images and poses before allowing the finite motion schedule.
  deadline=time.monotonic()+35
  while time.monotonic()<deadline:
   time.sleep(1)
   p=out/'vision_status.json'
   if p.exists() and json.loads(p.read_text()).get('frames',0)>0:break
   if server.poll() is not None or vision.poll() is not None:raise RuntimeError('Simulator or vision failed preflight')
  else:raise RuntimeError('No image keyframe with metric camera pose')
  motion=launch('motion',['python3',str(pipe/'paired_motion.py'),*args]);launch('guard',['python3',str(pipe/'command_guard.py'),str(motion.pid),str(out/'command_lease.json'),*args])
  motion.wait(timeout=195);kill(procs['guard']);time.sleep(2);kill(record,20);record=None;kill(vision,20)
  status=json.loads((out/'motion.json').read_text());success=status['reason']=='schedule_complete'
  config['motion_completed']=success;config['motion_reason']=status['reason'];config['wheel_distance_m']=status['wheel_distance_m']
  config['capture_finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(trial/'run_manifest.json').write_text(json.dumps(config,indent=2))
  # Reconstruction uses recorded image coordinates and fused poses, no scene path.
  refine=launch('reconstruct',['python3',str(pipe/'stable_reconstruct.py'),str(out),str(trial/'stable')]);refine.wait(timeout=600)
  config['reconstruction_exit_code']=refine.returncode
  if refine.returncode==0:config['result']=json.loads((trial/'stable/validation.json').read_text())
  (trial/'run_manifest.json').write_text(json.dumps(config,indent=2))
  print(json.dumps({'condition':condition,'motion_completed':success,'accepted_landmarks':config.get('result',{}).get('accepted_landmarks'),'dataset_pixel_gate_pass':config.get('result',{}).get('dataset_pixel_gate_pass')}),flush=True)
 except Exception as e:
  config['exception']=repr(e);(trial/'run_manifest.json').write_text(json.dumps(config,indent=2));raise
 finally:
  # Commands and recorder stop first, irrespective of failure during processing.
  kill(motion);kill(record,20)
  for name in ['guard','vision','reconstruct','slam','odometry','image','bridge','server','telemetry']:kill(procs.get(name),15)
  hashes={str(p.relative_to(trial)):hashlib.sha256(p.read_bytes()).hexdigest() for p in trial.rglob('*') if p.is_file() and p.name!='checksums.json'}
  (trial/'checksums.json').write_text(json.dumps(hashes,indent=2))
 return trial

def main():
 if os.environ.get('ROS_DISTRO')!='jazzy':raise SystemExit('Source ROS Jazzy first')
 if not (ROOT/'scene_manifest.json').exists():raise SystemExit('Build and validate paired worlds first')
 (ROOT/'runs').mkdir(exist_ok=True)
 for condition in ['uniform','textured']:one(condition)
 (ROOT/'pair_complete.json').write_text(json.dumps({'complete':True,'conditions':['uniform','textured'],'interpretation':'one matched pilot pair; not independent replications'}));print('PAIR_COMPLETE',flush=True)
if __name__=='__main__':main()
