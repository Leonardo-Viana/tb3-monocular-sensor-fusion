# Working manuscript notes

Working title: **Texture and Map-Revision Stability in RGB-Only Sparse Reconstruction with Planar LiDAR and Inertial–Wheel Pose Priors**

## Potential contribution

A reproducible systems experiment may be useful to researchers and educators working with affordable mobile robots and limited computing resources. The candidate contribution is an evaluated trade-off between texture, sparse geometry availability, graph-update stability and resource cost, with a transparent RGB-only geometry constraint. Rigid submaps and sensor fusion are established ideas; novelty is not assumed.

## Evidence collected before the texture pilot

A TurtleBot3 Waffle Gazebo session produced 3,391 image keyframes and 3,473 retained tracks. A revised local-submap back end accepted 219 sparse points. Of these, 214 had evaluable reserved observations: 591 test pixels, median reprojection error 0.867 px, p90 2.355 px, maximum 17.915 px. Five points lacked sufficient other-track support for their test-camera poses. Thirty-four test observations exceeded 3 px and four exceeded 8 px.

For a common population of 73 track IDs across two saved graph revisions, the old output changed by a median of 7.86 cm (p90 28.80 cm), whereas reanchoring the fixed local submaps changed global positions by a median of 2.91 cm (p90 4.55 cm). This is a controlled response to graph updates. Internal rigidity is a property of the chosen representation, not a measurement of accuracy.

A separate 133.606 s raw recording contains 336,977 messages, including 4,049 RGB images. It was read back successfully; the first image decoded as 1920 x 1080 RGB. It was not used to produce the preceding reconstruction metrics.

These observations are developmental and from one simulated geometry. Preserve them in the paper history, but do not combine them with the prospective matched-scene pilot as equivalent replicates.

## Proposed paper structure

1. Problem and operational constraints.
2. Related work and distinction between LiDAR-derived feature depth and pose-only LiDAR assistance.
3. Software/data interfaces; uncertainty and flat-floor assumptions.
4. Paired scene generation and frozen evaluation protocol.
5. Results, failures, resource measurements and ablations.
6. Limits, reproduction instructions and teaching implications.

## Required work before stronger claims

- Repeated runs and more than one scene geometry.
- Appropriate external baselines, including a monocular-inertial configuration where initialization is feasible.
- Ablations of inertial support and LiDAR pose corrections, with unchanged evaluation data.
- Explicit cross-revisit associations or a restricted claim that does not imply their presence.
- A separate accuracy reference if absolute metric accuracy is to be claimed.
- Real TurtleBot3 tests when the hardware is available.
- Review data/software licensing and contribution statements before any public release.

The assistant participated in engineering and analysis. Keep a record of human decisions and automated code generation for an appropriate disclosure; do not assign authorship automatically. Nothing has been submitted or publicly published.

## Completed texture pilot

The matched pilot was completed on 30 September 2026. See PILOT_REPORT.md for the full result, including 19 versus 443 accepted points, held-out tail failures, resource definitions and one-run limitations. Do not merge these runs with the historical development dataset as independent replicates.
