# Texture-controlled RGB monocular reconstruction: pilot report

**Experiment date:** 30 September 2026. **Status:** completed engineering pilot, one run per condition. No confirmatory statistical claim.

## Outcome

Adding visible surface texture was associated with substantially more accepted sparse monocular landmarks in this matched pilot: 443 versus 19 (23.32-fold). Median reserved-observation reprojection error decreased from 1.169 to 0.370 pixels. Both runs completed the predeclared command schedule and passed the predeclared aggregate pixel gate. These results concern availability and internal image consistency of sparse geometry, not absolute metric accuracy or complete surface reconstruction.

## Experimental setup

The same TurtleBot3 Waffle geometry, RGB camera, 2D LiDAR, IMU, wheel model, lighting, physics settings and initial placement were used in two Gazebo Harmonic worlds. Only albedo-image paths differ between the paired scene files. The control has uniform mean-matched albedo images; the treatment has deterministic grayscale irregular patterns. Both use identical UV mapping and PBR material modulation. The shader-matched control is different from the historic unmodified TurtleBot3 material configuration.

The initial camera views confirm visible texture on obstacles and walls. The floor appears uniformly bright in both rendered views, so this pilot does not establish an effective floor-texture manipulation despite the generated floor albedo asset. Do not describe every surface as visibly textured.

The original camera remained 1920 × 1080 at 30 Hz. Images were resized to 960 × 540 for feature tracking. Metric camera-pose priors came from wheel velocity, raw gyroscope/accelerometer processing and planar LiDAR SLAM. Three-dimensional landmarks came from RGB image-ray triangulation. No depth image, magnetometer, IMU orientation field, simulator pose or scene mesh was passed to reconstruction. The scene builder reads geometry only to author the simulator environment. The estimator has a flat-floor prior and is not a full six-degree-of-freedom visual–inertial SLAM implementation.

An Intel Core i5-12400 Dell Vostro with approximately 7.4 GiB usable RAM and integrated Intel UHD 730 graphics performed both capture and reconstruction. ROS 2 Jazzy was used. The original simulation was paused before the pilot; earlier application processes remained resident. Each trial used isolated ROS domain 73 and a separate Gazebo transport partition. Capture used server-only Gazebo rendering through the existing display environment. The simulator GUI and the new result-viewing RViz were started after the measured trials, so their resource costs are not in the trial stack measurements.

## Paired results

| Measure | Uniform | Textured |
|---|---:|---:|
| Completed motion schedule | Yes | Yes |
| Wheel-integrated absolute travel | 2.638093 m | 2.637989 m |
| Retained image keyframes | 171 | 169 |
| Retained track IDs | 122 | 2,697 |
| Accepted sparse 3D landmark IDs | 19 | 443 |
| Accepted landmarks above z = 0.15 m | 2 | 286 |
| Scored test observations | 71 | 1,679 |
| Test median reprojection error | 1.169 px | 0.370 px |
| Test p90 reprojection error | 5.190 px | 1.010 px |
| Test maximum reprojection error | 35.602 px | 71.593 px |
| Test observations exceeding 8 px | 2 (2.82%) | 20 (1.19%) |
| Predeclared aggregate pixel gate | Pass | Pass |
| Offline reconstruction wall time | 5.31 s | 20.43 s |
| Controller wall time, including startup/drain | 100.88 s | 94.49 s |
| Peak monitored stack PSS | 931.83 MiB | 920.96 MiB |
| Minimum host available memory | 2,060.67 MiB | 2,010.30 MiB |
| Raw recording size | 181.75 MiB | 399.99 MiB |
| Recorded RGB frames | 2,570 | 2,580 |

The z threshold is a descriptive height bin, not a ground-truth semantic label. Different track IDs can refer to the same physical feature. The two wheel-travel estimates differ by approximately 0.105 mm; this supports comparable travel but does not prove identical trajectories or ground-truth poses. Identical commands, seed 23 and initial world settings do not guarantee identical asynchronous numerical realizations.

All three contributing reconstruction blocks converged in each condition. Every accepted point had at least one scorable held-out observation. Training and validation observations selected the points; test observations were evaluated afterward. Pixels from a run are correlated and are not independent experimental replicates.

## Recording verification and resource interpretation

Every stored MCAP message was traversed: 346,457 messages in U and 342,872 in T. Per-topic counts matched recording metadata. First and last RGB messages in each bag decoded to 1080 × 1920 × 3 arrays. Final recorded velocity commands were zero. This checks file readability and count consistency; it does not prove zero message loss during acquisition. U had 2,573 camera-calibration messages versus 2,570 stored images, which is retained as an acquisition discrepancy. Raw recordings span approximately 84.887 and 85.144 simulation seconds, including setup and stop margins around the 74-second motion schedule.

PSS is the sampled sum of the monitored trial process trees, not total computer memory. RSS sums double-count shared pages. Existing background applications and approximately 2.38 GiB of previously occupied swap remained on the host. Texture did not produce an obvious increase in sampled peak stack memory in this pair, but the small difference must not be interpreted as a memory advantage. Textured RGB recordings were about 2.2 times larger, and sparse reconstruction took about 3.8 times longer.

The current telemetry stores CPU time summed over currently live processes. That total can decrease when processes exit. No aggregate CPU-efficiency conclusion is drawn from it; future logging should preserve per-process lifetime CPU totals.

## Failures, limitations and engineering findings

- Before capture, the SDF validator rejected duplicate visual/collision names inherited from the scene. Renaming visuals resolved this without changing collisions or sensors. Both worlds passed the paired structural equality check; the deployed uniform SDF passed `gz sdf -k`.
- Initial uniform and textured rendering views were visually inspected. Neutral material modulation was introduced before either trial to make originally black surfaces carry visible patterns; this is documented in the pre-capture amendment.
- The reserved-pixel tail remains problematic: the textured maximum is 71.59 px and 20 observations exceed 8 px. Passing a median/p90 gate does not make every landmark or observation reliable. No thresholds were retuned and no points were deleted after observing these test errors.
- The command loop emitted about 1.6 kHz of velocity messages because subscription callbacks drove its iterations without an explicit publication period. Both trials used the same frozen controller. This is unnecessary overhead, not a desirable control frequency. Rate-limit publication before a new experimental series and freeze a new revision; do not overwrite this pair.
- The Intel/RViz occupancy-texture shader reported a sampler-link error during post-trial viewing. The saved LiDAR occupancy cells are now displayed as a flat z = 0 point layer, alongside RGB-only 3D points. This changes visualization only and does not extrude walls or supply LiDAR depth to reconstruction.
- Fixed order U then T, one simulation seed, one geometry, no independent repeat runs, no inter-revisit feature association, flat-floor priors and no metric ground truth limit generalization.
- The new compact asymmetric two-room environment has **not** been evaluated. This completed pair is the texture-control stage that precedes that geometry change.

## Interpretation for an eventual paper

A reproducible low-resource systems study could be useful, particularly if it quantifies when texture helps, how map revisions affect sparse geometry, and what resources and failure modes occur. This pair provides a promising descriptive result, not proof of a new sensor-fusion method or superiority to established systems.

Before a paper's main claims are frozen: repair command-rate logging, diagnose held-out tail failures without tuning against the same test observations, run counterbalanced repeats with new seeds, test a second geometry, and add relevant external baselines and sensor ablations. Absolute metric accuracy requires a separately designed reference protocol. The absence of a physical TurtleBot3 does not prevent these simulation experiments, but transfer to real hardware remains untested.

## Saved evidence

`pilot_results.json` contains exact descriptive values. `pilot_comparison.png/.pdf` shows initial RGB views and accepted sparse points on shared axes. `test_error_ecdf.png/.pdf` preserves the full reserved-error tail. Each run directory contains reconstruction evidence, frozen data, console logs, telemetry and bag metadata/readback results. Full raw MCAP recordings and all original keyframe JPEGs remain on the Dell at the paths recorded in each `bag_validation.json`; the portable archive includes selected JPEGs and complete numerical tracks/keyframes, but excludes raw MCAP payloads.

No article has been submitted or publicly published.
