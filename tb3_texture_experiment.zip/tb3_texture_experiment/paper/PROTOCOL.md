# Protocol v1 — Texture-controlled monocular reconstruction pilot

Recorded before collecting the new paired runs on 2026-09-29 (America/Maceio).
Status: prospective pilot protocol, not a completed confirmatory study.

## Research questions

1. With fixed geometry, sensor configuration, motion commands and estimator parameters, does surface texture increase the availability of triangulatable RGB tracks without degrading reserved-pixel prediction?
2. Does rigid local-submap placement reduce sensitivity to 2D SLAM graph revisions compared with independently rewarping each camera pose?
3. What memory, CPU and simulation-speed costs occur on an 8 GB desktop with integrated graphics?

## Scope and permitted information

3D landmarks must be generated from RGB image rays. Metric pose priors may use wheel velocities, raw gyroscope/accelerometer measurements and planar LiDAR SLAM. Depth/RGB-D, magnetometer, Imu.orientation, simulator poses and world geometry are not estimator inputs. Scene geometry is accessible only to the scene-authoring tool. The controller must use live permitted sensors, never the world file. This separation is a code/data interface rule, not a security sandbox claim.

This is sparse reconstruction under a flat-floor motion prior. It is not a claim of dense mapping, absolute metric accuracy, full 6-DoF inertial fusion or a complete autonomous exploration solution.

## Scene conditions

U: uniform textures, each matched to the mean intensity of its paired textured surface.
T: deterministic irregular grayscale patterns at 512 x 512 pixels; seed 20260929 plus surface index.

The two files differ only in albedo image URI. Geometry, object poses, collision definitions, physics, lighting, camera configuration, noise settings and other sensors are identical. Both use the same PBR material settings and UV-mapped meshes. UVs are added without changing upstream vertex or normal arrays; the ground visual is represented by an equivalent 100 x 100 m planar quad. Its original collision plane is unchanged.

U is an original-like, shader-matched control, NOT a bit-identical replay of the historical stock-material scene. The historic experiment is development evidence, not a matched comparison with T.

## Frozen processing

Track front end: current Shi–Tomasi/KLT implementation, 960 x 540 processing, 450 active-track budget, forward/backward consistency filtering, at most 24 observations per track. Original RGB sensor remains 1920 x 1080 at 30 Hz with its existing Gaussian noise.

Pose priors: wheel/raw-IMU filter plus 2D slam_toolbox; all configuration and code hashes recorded.

Back end: stable_reconstruct.py as frozen for this pilot. Local block size 64; minimum baseline 0.15 m and parallax 2 degrees; robust bundle adjustment with temporal regularization. Track-specific deterministic train/validation/test partition precedes fitting. Test pixels never select individual points. The dataset gate is median <=3 px, p90 <=8 px, at least 30 scored test observations, and convergence for every contributing block. A failed dataset remains a reported failed outcome; parameters will not be changed in response to its test error.

## Motion and recording

One identical simulation-time command schedule from a fresh initial state per condition: stationary warm-up, forward translation, a short pan in each direction, additional translation and reverse along the travelled corridor. Maximum linear speed 0.06 m/s; angular speed 0.20 rad/s. The exact schedule is versioned with the controller before execution.

An independent process watchdog and live LiDAR guard stop motion on stale inputs, low memory, inadequate clearance, unexpected velocity publishers or wall-time expiry. Safety stops invalidate trajectory matching and are reported rather than excluded silently. Initial robot placement is a scenario setting; its numerical pose is not passed to the estimator.

Record all original RGB images/calibration, scan, raw IMU, wheel odometry, joint states, clock, TF and commanded velocity. Save derived keyframes/tracks, graph snapshots, per-point evidence, termination reason, console logs, software versions and file hashes. Raw IMU messages naturally contain an orientation field; processing must continue to ignore it.

## Analysis and units

Primary descriptive outcomes: number of accepted landmarks, accepted non-ground landmarks, track lengths, valid-test fraction, reserved-pixel median/p90/max error, failure counts and reasons. Counts are not direct measures of surface completeness. Multiple IDs may represent the same physical feature; inter-revisit visual reidentification is not yet implemented.

Resource outcomes: process-tree proportional-set-size (PSS) where available, aggregate RSS labelled as such, process CPU seconds, host available memory and swap, wall duration and simulated duration. No energy-consumption claim is made. Capture/evaluation and reconstruction phases are timed separately; any off-machine processing must be explicitly identified.

The independent unit is a whole run, not a feature, frame or pixel. Initially collect one U and one T run as an engineering pilot. Do not compute inferential significance from thousands of correlated pixels. For a later confirmatory study, freeze the repaired pipeline again, use at least five runs per condition with counterbalanced order and varied simulation seeds, then add a second geometry and suitable baseline algorithms. Pilot results must not be relabelled as confirmatory.

## Threats and decision rules

Trajectory differences, incomplete recording, frame drops, lighting/geometry mismatches, noise realization, thermal/load variation, submap seams, repeated textures, motion priors and test-pixel temporal correlation are recorded as limitations. World geometry remains unavailable for accuracy scoring under the current user constraints; absolute metric accuracy is therefore not established. A future independent reference protocol is a separate design decision.

Do not assert a new SLAM algorithm, state-of-the-art accuracy, memory superiority or publication readiness based on this pilot alone. Parameter changes after seeing a result must create a new protocol/code revision and a new run ID. Retain failures and superseded outputs.
