# Initial related-work ledger (not a systematic review)

Checked against primary sources on 2026-09-29. Bibliographic discovery remains incomplete.

- Campos et al. (2021), *ORB-SLAM3: An Accurate Open-Source Library for Visual, Visual-Inertial and Multi-Map SLAM*, IEEE Transactions on Robotics 37(6), 1874–1890. Primary implementation: https://github.com/UZ-SLAMLab/ORB_SLAM3 ; paper: https://arxiv.org/abs/2007.11898 . Relevant as a established monocular-inertial/multi-map baseline. No benchmark against it has yet been performed here.
- Graeter, Wilczynski and Lauer (2018), *LIMO: Lidar-Monocular Visual Odometry*, IROS, DOI 10.1109/IROS.2018.8594394. Paper: https://arxiv.org/abs/1807.07524 ; institutional record: https://publikationen.bibliothek.kit.edu/1000094358 ; implementation: https://github.com/johannes-graeter/limo . It uses LiDAR depth extraction for image tracks, unlike the present RGB-ray geometry / 2D pose-prior constraint. This difference alone does not establish novelty.
- *VILO SLAM: Tightly Coupled Binocular Vision–Inertia SLAM Combined with LiDAR* (2023), Sensors 23(10), 4588, DOI 10.3390/s23104588. Publisher: https://www.mdpi.com/1424-8220/23/10/4588 . It combines binocular visual–inertial estimation with low-cost 2D LiDAR. Relevant prior art for affordable multi-sensor fusion; the camera configuration differs.
- Gazebo Sim 8 headless rendering documentation: https://gazebosim.org/api/sim/8/headless_rendering.html . EGL rendering is available with OGRE2; actual rendering mode and hardware behavior must be recorded for our runs rather than inferred from documentation.

The current literature check does not establish that this experiment is the first of its kind. The intended value is a carefully bounded, reproducible empirical result.
