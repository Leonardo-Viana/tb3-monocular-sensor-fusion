"""Read every MCAP message; decode endpoint RGB frames and audit command frequency."""
import json,collections
from pathlib import Path
import rosbag2_py,cv2,numpy as np,yaml
from rclpy.serialization import deserialize_message
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import TwistStamped
root=Path(__file__).resolve().parent
for trial in sorted((root/'runs').iterdir()):
 p=trial/'raw';r=rosbag2_py.SequentialReader();r.open(rosbag2_py.StorageOptions(uri=str(p),storage_id='mcap'),rosbag2_py.ConverterOptions('',''))
 counts=collections.Counter();first=None;last=None;start=None;end=None;cmdframes=collections.Counter();lastcmd=None
 while r.has_next():
  t,b,stamp=r.read_next();counts[t]+=1;start=stamp if start is None else start;end=stamp
  if t=='/camera/image_raw/compressed':
   if first is None:first=b
   last=b
  if t=='/cmd_vel':
   m=deserialize_message(b,TwistStamped);cmdframes[m.header.frame_id]+=1;lastcmd=[m.twist.linear.x,m.twist.angular.z]
 shapes=[]
 for raw in [first,last]:
  m=deserialize_message(raw,CompressedImage);im=cv2.imdecode(np.frombuffer(m.data,np.uint8),cv2.IMREAD_COLOR);shapes.append(list(im.shape) if im is not None else None)
 meta=yaml.safe_load((p/'metadata.yaml').read_text())['rosbag2_bagfile_information'];expected={t['topic_metadata']['name']:t['message_count'] for t in meta['topics_with_message_count']}
 report={'readable_messages':sum(counts.values()),'topics':dict(counts),'matches_metadata':dict(counts)==expected,'endpoint_rgb_shapes':shapes,'bag_bytes':sum(x.stat().st_size for x in p.iterdir()),'bag_path':str(p),'stamp_duration_s':(end-start)*1e-9,'command_frame_ids':dict(cmdframes),'last_command':lastcmd,'note':'All messages traversed; only endpoint images decoded. Traversal is not a proof of zero acquisition loss.'}
 (trial/'bag_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
