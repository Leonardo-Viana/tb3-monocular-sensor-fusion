"""Simulation-only frozen command schedule. No world-file or simulator-pose access."""
import os,json,time,signal,threading,math
from pathlib import Path
import numpy as np,rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan,Imu,CompressedImage
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TwistStamped
SCHEDULE=[('warmup',4,0,0),('forward_1',16,.06,0),('pause_1',2,0,0),('pan_left',4,0,.20),('pan_right',8,0,-.20),('pan_center',4,0,.20),('pause_2',2,0,0),('forward_2',6,.06,0),('pause_3',2,0,0),('reverse',22,-.06,0),('settle',4,0,0)]
ROOT=Path(__file__).parent;OUT=ROOT/'output';LEASE=OUT/'command_lease.json'
def mem_mb():return int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))/1024
class Motion(Node):
 def __init__(self):
  super().__init__('texture_pilot_motion');self.last={};self.messages={};self.external=False;self.finished=False;self.stop=False;self.tick=time.monotonic();self.log=[];self.distance=0.;self.last_od=None
  self.pub=self.create_publisher(TwistStamped,'/cmd_vel',10)
  for typ,topic in [(LaserScan,'/scan'),(Odometry,'/odom'),(Imu,'/imu'),(CompressedImage,'/camera/image_raw/compressed')]:self.create_subscription(typ,topic,lambda m,t=topic:self.receive(t,m),qos_profile_sensor_data)
  self.create_subscription(TwistStamped,'/cmd_vel',self.command,10)
  self.thread=threading.Thread(target=self.watchdog,daemon=True);self.thread.start()
 def receive(self,t,m):
  self.last[t]=time.monotonic();self.messages[t]=m
  if t=='/odom':
   now=m.header.stamp.sec+m.header.stamp.nanosec*1e-9
   if self.last_od is not None and 0<now-self.last_od<.2:self.distance+=abs(m.twist.twist.linear.x)*(now-self.last_od)
   self.last_od=now
 def command(self,m):
  if m.header.frame_id not in ['texture_pilot','mono_autonomy_guard']:self.external=True
 def send(self,v=0.,w=0.,heartbeat=True):
  m=TwistStamped();m.header.stamp=self.get_clock().now().to_msg();m.header.frame_id='texture_pilot';m.twist.linear.x=float(v);m.twist.angular.z=float(w);self.pub.publish(m)
  if heartbeat:
   self.tick=time.monotonic();tmp=LEASE.with_suffix('.tmp');tmp.write_text(json.dumps({'monotonic':self.tick}));tmp.replace(LEASE)
 def watchdog(self):
  while not self.finished:
   if time.monotonic()-self.tick>.6:
    try:self.send(heartbeat=False)
    except Exception:pass
   time.sleep(.05)
 def run(self):
  wall=time.monotonic();start=None;reason='running';lastlog=-1
  try:
   while not self.stop and time.monotonic()-wall<180:
    rclpy.spin_once(self,timeout_sec=.025);now=time.monotonic();clock=self.get_clock().now().nanoseconds*1e-9
    if len(self.last)<4:
     self.send()
     if now-wall>15:reason='missing_sensors';break
     continue
    if self.external:reason='external_command';break
    if any(now-self.last[t]>.8 for t in ['/scan','/odom','/imu']) or now-self.last['/camera/image_raw/compressed']>1.5:reason='stale_sensors';break
    if mem_mb()<600:reason='low_memory';break
    if start is None:start=clock
    elapsed=clock-start;cum=0;phase=None
    for name,duration,v,w in SCHEDULE:
     if elapsed<cum+duration:phase=name;break
     cum+=duration
    if phase is None:reason='schedule_complete';break
    scan=self.messages['/scan'];r=np.array(scan.ranges);a=scan.angle_min+np.arange(len(r))*scan.angle_increment;ok=np.isfinite(r)&(r>=scan.range_min)&(r<=scan.range_max)
    if ok.sum()<40:reason='insufficient_scan';break
    x=r[ok]*np.cos(a[ok])-.064;y=r[ok]*np.sin(a[ok]);minimum=float(np.hypot(x,y).min())
    if minimum<.235:reason='body_clearance';break
    corridor=abs(y)<.23;front=x[corridor&(x>0)];rear=-x[corridor&(x<0)]
    if (v>0 and len(front) and front.min()<.34) or (v<0 and len(rear) and rear.min()<.34):reason='directional_clearance';break
    self.send(v,w)
    if elapsed-lastlog>.2:
     od=self.messages['/odom'];self.log.append({'sim_t':clock,'elapsed':elapsed,'phase':phase,'command':[v,w],'measured_twist':[od.twist.twist.linear.x,od.twist.twist.angular.z],'min_scan_m':minimum});lastlog=elapsed
   else:reason='interrupted' if self.stop else 'wall_deadline'
  finally:
   end=time.monotonic()+1.2
   while time.monotonic()<end:self.send();rclpy.spin_once(self,timeout_sec=.025)
   self.finished=True;self.thread.join(timeout=1)
   report={'reason':reason,'wall_seconds':time.monotonic()-wall,'wheel_distance_m':self.distance,'schedule':SCHEDULE,'samples':self.log,'uses_world_geometry':False}
   (OUT/'motion.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='samples'}),flush=True)
def main():
 OUT.mkdir(exist_ok=True);rclpy.init();n=Motion();signal.signal(signal.SIGTERM,lambda *a:setattr(n,'stop',True));signal.signal(signal.SIGINT,lambda *a:setattr(n,'stop',True))
 try:n.run()
 finally:n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
