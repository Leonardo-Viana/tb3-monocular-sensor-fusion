import json,time,sys,signal
from pathlib import Path
import psutil
root=Path(sys.argv[1]);keep=True
signal.signal(signal.SIGTERM,lambda *a:globals().update(keep=False))
with (root/'resources.jsonl').open('a',buffering=1) as f:
 while keep:
  pids=json.loads((root/'pids.json').read_text());seen={}
  for name,pid in pids.items():
   try:
    p=psutil.Process(pid)
    for c in [p]+p.children(recursive=True):seen[c.pid]=c
   except psutil.Error:pass
  rss=pss=cpu=0.;details=[]
  for pid,p in seen.items():
   try:
    m=p.memory_full_info();c=p.cpu_times();rss+=m.rss;pss+=getattr(m,'pss',0);cpu+=c.user+c.system;details.append([pid,p.name(),m.rss,getattr(m,'pss',0)])
   except psutil.Error:pass
  mem=psutil.virtual_memory();swap=psutil.swap_memory();f.write(json.dumps({'wall_time':time.time(),'monotonic':time.monotonic(),'rss_bytes_sum':rss,'pss_bytes_sum':pss,'cpu_seconds_live_processes':cpu,'host_available_bytes':mem.available,'host_swap_used_bytes':swap.used,'processes':details})+'\n');time.sleep(1)
