"""Static display of saved pilot evidence. Publishes no robot commands or TF."""
import json
from pathlib import Path
import numpy as np,rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy
from sensor_msgs.msg import PointCloud2,PointField
from nav_msgs.msg import OccupancyGrid
from visualization_msgs.msg import Marker
from std_msgs.msg import Header
ROOT=Path(__file__).resolve().parent
class View(Node):
 def __init__(self):
  super().__init__('texture_pilot_saved_view');self.runs={c:ROOT/'runs'/f'{c}_seed23_r01' for c in ['uniform','textured']};q=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)
  self.points={c:json.loads((p/'stable/stable_landmarks.json').read_text()) for c,p in self.runs.items()};self.summaries={c:json.loads((p/'stable/validation.json').read_text()) for c,p in self.runs.items()}
  self.pubs={c:self.create_publisher(PointCloud2,'/pilot/'+c,q) for c in self.runs};self.label=self.create_publisher(Marker,'/pilot/status',q);self.map_pub=self.create_publisher(OccupancyGrid,'/pilot/lidar_map',q);self.outline=self.create_publisher(PointCloud2,'/pilot/lidar_outline',q)
  self.map=json.loads((self.runs['textured']/'map_snapshot.json').read_text());self.create_timer(2.,self.publish);self.publish()
 def publish(self):
  h=Header(stamp=self.get_clock().now().to_msg(),frame_id='mono_map')
  for c,pts in self.points.items():
   a=np.zeros(len(pts),dtype=[('x','<f4'),('y','<f4'),('z','<f4'),('rgb','<u4')])
   for i,p in enumerate(pts):
    a[i]['x'],a[i]['y'],a[i]['z']=p['xyz'];r,g,b=p['rgb'];a[i]['rgb']=(int(r)<<16)|(int(g)<<8)|int(b)
   m=PointCloud2();m.header=h;m.height=1;m.width=len(a);m.point_step=16;m.row_step=16*len(a);m.is_dense=True;m.fields=[PointField(name=n,offset=4*i,datatype=PointField.FLOAT32 if i<3 else PointField.UINT32,count=1) for i,n in enumerate(['x','y','z','rgb'])];m.data=a.tobytes();self.pubs[c].publish(m)
  d=self.map;m=OccupancyGrid();m.header=h;m.info.resolution=d['resolution'];m.info.width=d['width'];m.info.height=d['height'];m.info.origin.position.x,m.info.origin.position.y,m.info.origin.position.z=d['position'];m.info.origin.orientation.x,m.info.origin.orientation.y,m.info.origin.orientation.z,m.info.origin.orientation.w=d['quaternion'];m.data=d['data'];self.map_pub.publish(m)
  yy,xx=np.where(np.asarray(d['data']).reshape(d['height'],d['width'])>=65);cloud=np.zeros((len(xx),3),np.float32);cloud[:,0]=(xx+.5)*d['resolution'];cloud[:,1]=(yy+.5)*d['resolution']
  from scipy.spatial.transform import Rotation
  cloud=(cloud@Rotation.from_quat(d['quaternion']).as_matrix().T+np.asarray(d['position'])).astype('<f4')
  m=PointCloud2();m.header=h;m.height=1;m.width=len(cloud);m.point_step=12;m.row_step=12*len(cloud);m.is_dense=True;m.fields=[PointField(name=n,offset=4*i,datatype=PointField.FLOAT32,count=1) for i,n in enumerate(['x','y','z'])];m.data=cloud.tobytes();self.outline.publish(m)
  t=Marker();t.header=h;t.ns='saved_pilot';t.id=0;t.type=Marker.TEXT_VIEW_FACING;t.action=Marker.ADD;t.pose.orientation.w=1.;t.pose.position.x=.7;t.pose.position.y=-1.3;t.pose.position.z=.8;t.scale.z=.09;t.color.r=.05;t.color.g=.08;t.color.b=.13;t.color.a=1.
  u=self.summaries['uniform'];s=self.summaries['textured'];t.text=f"Saved pilot | RGB monocular\nUniform: {u['accepted_landmarks']} | Textured: {s['accepted_landmarks']} sparse points\nTest median: {s['test_pixels']['median']:.2f} px | max: {s['test_pixels']['max']:.1f} px\nOne run per condition; metric accuracy unverified";self.label.publish(t)
def main():
 rclpy.init();n=View()
 try:rclpy.spin(n)
 except KeyboardInterrupt:pass
 finally:n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
