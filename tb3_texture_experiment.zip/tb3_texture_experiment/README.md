# TurtleBot3 RGB-only texture pilot

This archive contains the completed 30 September 2026 uniform/textured pilot and English research documentation. Start with `paper/PILOT_REPORT.md`. Results: 19 versus 443 accepted sparse RGB-triangulated landmark IDs; one run per condition, no metric ground truth.

## Contents

- `paper/`: prospective protocol, original freeze hashes, operational amendments, pilot results/report, figures and initial literature ledger.
- `build_worlds.py`, `source/`, `worlds/`: reproducible paired scene generation. Scene geometry is consumed by the authoring/simulator layer only.
- `pipeline/`: frozen wheel/raw-IMU pose filtering, 2D LiDAR SLAM settings, monocular tracking, stable local-submap reconstruction and bounded pilot motion.
- `runs/`: numeric tracks/keyframes, reconstruction evidence, selected camera views, motion logs, telemetry, metadata and raw-bag verification.
- `view_pilot.py`, `pilot.rviz`: static saved-evidence display. They publish no motor commands. The LiDAR outline is planar and is not a source of 3D feature depths.
- `analyze_pilot.py`: recomputes descriptive tables and scientific figures without changing accepted points.

## Replay numerical analysis

With Python, NumPy, SciPy, Matplotlib and Pillow installed, run `python3 analyze_pilot.py` from this directory. To re-run reconstruction, use `python3 pipeline/stable_reconstruct.py runs/textured_seed23_r01/pipeline/output new_reconstruction_directory`. Keep the existing results intact. ROS is not needed for these offline steps.

## ROS/Gazebo display on the Dell

The live project is `/home/lpviana/tb3_texture_experiment_20260929`. The new RViz shows **saved pilot evidence** and supports toggling the uniform point layer. The Gazebo GUI opens the textured world paused, with no autonomous controller launched. The original simulation was paused and its previous results retained.

For a fresh display, source `/opt/ros/jazzy/setup.bash`, set `ROS_DOMAIN_ID=73`, and run `python3 view_pilot.py` and `rviz2 -d pilot.rviz` in that environment. Avoid duplicate view nodes if the existing display session is still active. Display-process metadata is retained on the Dell in `display_session.json`.

## Reproducing future captures

The tested platform used ROS 2 Jazzy, Gazebo Harmonic, turtlebot3_gazebo 2.3.7, ros_gz_bridge 1.0.24 and slam_toolbox 2.8.5. Before moving this directory, rerun `python3 build_worlds.py` at its new absolute path: generated SDF image/mesh paths depend on the installation directory. Set `GZ_SIM_RESOURCE_PATH` to include `/opt/ros/jazzy/share/turtlebot3_gazebo/models`. The original camera and collision resources come from those installed packages.

`run_pair.py` is the exact pilot orchestrator and deliberately refuses to overwrite its existing run directories. Do not reuse it unchanged for a new series: first rate-limit its motion-controller publication loop, assign new run IDs, and document a new protocol/code freeze. It commands a simulated robot in an isolated ROS/Gazebo environment. The historical command flood is preserved for audit and must not be described as a recommended control design.

Original raw bags occupy about 582 MiB combined on the Dell; all stored messages were traversed and endpoint images decoded. Raw MCAP payloads and most JPEGs are excluded from this portable archive. Paths, counts and hashes remain in the run evidence. Trial `checksums.json` files describe the full original remote trials, including files omitted from this archive. Root `ARCHIVE_SHA256.json` describes the files actually distributed here. `remote_scene_manifest.json` records the deployed scene hashes; `scene_manifest.json` describes the locally generated portable scene files.

This is sparse reconstruction under flat-floor and within-track validation assumptions. There is no complete-environment 3D map, dense depth inference, absolute accuracy certificate, independent replication, physical-robot result or novelty claim.
