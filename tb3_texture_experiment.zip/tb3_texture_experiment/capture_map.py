"""Read one derived LiDAR occupancy map; no robot commands or simulator poses."""
import json,sys,time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy
from nav_msgs.msg import OccupancyGrid
from pathlib import Path
rclpy.init();n=Node('pilot_map_snapshot');result=[]
def receive(m):
 p=m.info.origin
 result.append({'frame_id':m.header.frame_id,'resolution':m.info.resolution,'width':m.info.width,'height':m.info.height,'position':[p.position.x,p.position.y,p.position.z],'quaternion':[p.orientation.x,p.orientation.y,p.orientation.z,p.orientation.w],'data':list(m.data)})
q=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)
s=n.create_subscription(OccupancyGrid,'/mono/map',receive,q);deadline=time.monotonic()+15
while not result and time.monotonic()<deadline:rclpy.spin_once(n,timeout_sec=.2)
if not result:raise RuntimeError('No LiDAR occupancy map received')
Path(sys.argv[1]).write_text(json.dumps(result[-1]));n.destroy_node();rclpy.shutdown()
